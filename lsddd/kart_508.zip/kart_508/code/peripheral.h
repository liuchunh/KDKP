/*
 * peripheral.h
 *
 *  Created on: 2025��11��20��
 *      Author: 18905
 */

#ifndef CODE_PERIPHERAL_H_
#define CODE_PERIPHERAL_H_


//�ⲿ����
extern uint8 TIM_FLAG1;
extern uint8 TIM_FLAG2;
extern uint8 TIM_FLAG3 ;
extern uint8 key1_flag ;
extern uint8 key2_flag ;
extern uint8 key3_flag ;
extern uint8 key4_flag ;
extern uint8 key_val;
extern uint8 key_value;

extern int16 encoder_l ;
extern int16 encoder_r ;

typedef struct{
        int16 left_counter;
        int16 right_counter;
        int32 delta_l;
        int32 delta_r;
        int16 last_ecdcount_l;
        int16 last_ecdcount_r;
}Encoder_t;

extern Encoder_t Speed_ecd;
extern Encoder_t guandao_ecd;
extern Encoder_t Steer_ecd;

//�궨��
#define r_ecdcounter()    encoder_get_count(ENCODER_QUADDEC)
#define l_ecdcounter()    encoder_get_count(ENCODER_DIR)
#define BUZZER_PIN  (P33_10)      //������

#define KEY1                    (P20_6)    //������������   //P20_6  //P11_3
#define KEY2                    (P20_7)                               //P20_7 //P11_2
#define KEY3                    (P11_2)                                //P11_3 //P20_7
#define KEY4                    (P11_3)                               //P11_2 //P20_6
#define SWITCH2                 (P33_12)
#define SWITCH1                 (P33_11)

#define SERVO_MOTOR_PWM             (ATOM1_CH1_P33_9)
#define SERVO_MOTOR_FREQ            (50)
#define SERVO_MOTOR_DUTY(x)         ((float)PWM_DUTY_MAX/(1000.0/(float)SERVO_MOTOR_FREQ)*(0.27+(float)(x)/90.0))
#define SERVO_MOTOR_MID             (80)                                        //��ֵ80
#define SERVO_MOTOR_LMAX            (65)                                        //�����60
#define SERVO_MOTOR_RMAX            (95)                                       //�Ҵ���100

#define ENCODER_QUADDEC                 (TIM5_ENCODER)
#define ENCODER_QUADDEC_A               (TIM5_ENCODER_CH1_P10_3)
#define ENCODER_QUADDEC_B               (TIM5_ENCODER_CH2_P10_1)
#define ENCODER_DIR                     (TIM6_ENCODER)
#define ENCODER_DIR_PULSE               (TIM6_ENCODER_CH1_P20_3)
#define ENCODER_DIR_DIR                 (TIM6_ENCODER_CH2_P20_0)

#define PWM_L              (ATOM1_CH5_P02_5)
#define PWM_R              (ATOM0_CH7_P02_7)
#define PWM_V              (ATOM0_CH0_P21_2)
#define MOTOR_GPIO_L              (P02_6)
#define MOTOR_GPIO_R              (P02_4)
#define MOTOR_GPIO_V              (P21_3)
#define MOTER_MAX       (7000)
#define MOTER_MIN       (-7000)
#define S_MOTER_MAX       (5000)
#define S_MOTER_MIN       (-5000)
//����

void Init_All(void);
void Key_Init(void);   //����
void Key_Scan(void);
void Buzzer_Init(void);
void Buzzer_check(int time2); //���������Լ캯��
void Steer_init(void);               //�����ʼ��
void Steer_set(int angle);        //�������
void Steer_text(void);             //�������
void Encoder_Init(void);             //��������ʼ��
void Encoder_Get(Encoder_t *count);             //��������ȡ
void Motor_init(void);              //�����ʼ��
void Moter_Set(int moter_l , int moter_r);   //�������
int LimitMax(int input, int max);    //�������޷��β�
void Control(void);                          //���&�����������
void GPS_Init(void);
void Encoder_count_init(Encoder_t *count);
void VeerMoter_Set(int moter );
#endif /* CODE_PERIPHERAL_H_ */
