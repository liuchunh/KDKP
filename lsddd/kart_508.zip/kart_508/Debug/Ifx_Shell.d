Ifx_Shell.o :	../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.c
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.c :
Ifx_Shell.o :	..\code\Libraries\infineon_libraries\Service\CpuGeneric\SysSe\Comm\Ifx_Shell.h
..\code\Libraries\infineon_libraries\Service\CpuGeneric\SysSe\Comm\Ifx_Shell.h :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\user\TC264_config.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\user\TC264_config.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Ifx_Shell.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Ifx_Shell.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_Shell.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Ifx_Shell.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
Ifx_Shell.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
Ifx_Shell.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
