IfxPort_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.c :
IfxPort_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxPort_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxPort_cfg.h :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxPort_cfg.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxPort_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
