################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.c 

COMPILED_SRCS += \
libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.src 

C_DEPS += \
libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.d 

OBJS += \
libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.o 


# Each subdirectory must supply rules for building sources it contributes
libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.src: ../libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.c libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.o: libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.src libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-libraries-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-Ccu6-2f-TimerWithTrigger

clean-libraries-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-Ccu6-2f-TimerWithTrigger:
	-$(RM) libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.d libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.o libraries/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Ccu6/TimerWithTrigger/IfxCcu6_TimerWithTrigger.src

.PHONY: clean-libraries-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-Ccu6-2f-TimerWithTrigger

