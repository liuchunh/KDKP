################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.c 

COMPILED_SRCS += \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src 

C_DEPS += \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.d 

OBJS += \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.o 


# Each subdirectory must supply rules for building sources it contributes
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-libraries-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Math

clean-libraries-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Math:
	-$(RM) libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src

.PHONY: clean-libraries-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Math

