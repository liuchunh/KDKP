################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.c \
../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.c 

COMPILED_SRCS += \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.src \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.src 

C_DEPS += \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.d \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.d 

OBJS += \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.o \
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.o 


# Each subdirectory must supply rules for building sources it contributes
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.src: ../libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.c libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.o: libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-libraries-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-StdIf

clean-libraries-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-StdIf:
	-$(RM) libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Pos.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_PwmHl.src libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.d libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.o libraries/Libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_Timer.src

.PHONY: clean-libraries-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-StdIf

