################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.c \
../libraries/Libraries/seekfree_libraries/common/common.c \
../libraries/Libraries/seekfree_libraries/common/zf_assert.c 

COMPILED_SRCS += \
libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src \
libraries/Libraries/seekfree_libraries/common/common.src \
libraries/Libraries/seekfree_libraries/common/zf_assert.src 

C_DEPS += \
libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.d \
libraries/Libraries/seekfree_libraries/common/common.d \
libraries/Libraries/seekfree_libraries/common/zf_assert.d 

OBJS += \
libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.o \
libraries/Libraries/seekfree_libraries/common/common.o \
libraries/Libraries/seekfree_libraries/common/zf_assert.o 


# Each subdirectory must supply rules for building sources it contributes
libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src: ../libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.c libraries/Libraries/seekfree_libraries/common/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.o: libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src libraries/Libraries/seekfree_libraries/common/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/common/common.src: ../libraries/Libraries/seekfree_libraries/common/common.c libraries/Libraries/seekfree_libraries/common/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/common/common.o: libraries/Libraries/seekfree_libraries/common/common.src libraries/Libraries/seekfree_libraries/common/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/common/zf_assert.src: ../libraries/Libraries/seekfree_libraries/common/zf_assert.c libraries/Libraries/seekfree_libraries/common/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/common/zf_assert.o: libraries/Libraries/seekfree_libraries/common/zf_assert.src libraries/Libraries/seekfree_libraries/common/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-libraries-2f-Libraries-2f-seekfree_libraries-2f-common

clean-libraries-2f-Libraries-2f-seekfree_libraries-2f-common:
	-$(RM) libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.d libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.o libraries/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src libraries/Libraries/seekfree_libraries/common/common.d libraries/Libraries/seekfree_libraries/common/common.o libraries/Libraries/seekfree_libraries/common/common.src libraries/Libraries/seekfree_libraries/common/zf_assert.d libraries/Libraries/seekfree_libraries/common/zf_assert.o libraries/Libraries/seekfree_libraries/common/zf_assert.src

.PHONY: clean-libraries-2f-Libraries-2f-seekfree_libraries-2f-common

