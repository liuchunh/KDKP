################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libraries/Libraries/seekfree_libraries/zf_ccu6_pit.c \
../libraries/Libraries/seekfree_libraries/zf_eeprom.c \
../libraries/Libraries/seekfree_libraries/zf_eru.c \
../libraries/Libraries/seekfree_libraries/zf_eru_dma.c \
../libraries/Libraries/seekfree_libraries/zf_gpio.c \
../libraries/Libraries/seekfree_libraries/zf_gpt12.c \
../libraries/Libraries/seekfree_libraries/zf_gtm_pwm.c \
../libraries/Libraries/seekfree_libraries/zf_spi.c \
../libraries/Libraries/seekfree_libraries/zf_stm_systick.c \
../libraries/Libraries/seekfree_libraries/zf_uart.c \
../libraries/Libraries/seekfree_libraries/zf_vadc.c 

COMPILED_SRCS += \
libraries/Libraries/seekfree_libraries/zf_ccu6_pit.src \
libraries/Libraries/seekfree_libraries/zf_eeprom.src \
libraries/Libraries/seekfree_libraries/zf_eru.src \
libraries/Libraries/seekfree_libraries/zf_eru_dma.src \
libraries/Libraries/seekfree_libraries/zf_gpio.src \
libraries/Libraries/seekfree_libraries/zf_gpt12.src \
libraries/Libraries/seekfree_libraries/zf_gtm_pwm.src \
libraries/Libraries/seekfree_libraries/zf_spi.src \
libraries/Libraries/seekfree_libraries/zf_stm_systick.src \
libraries/Libraries/seekfree_libraries/zf_uart.src \
libraries/Libraries/seekfree_libraries/zf_vadc.src 

C_DEPS += \
libraries/Libraries/seekfree_libraries/zf_ccu6_pit.d \
libraries/Libraries/seekfree_libraries/zf_eeprom.d \
libraries/Libraries/seekfree_libraries/zf_eru.d \
libraries/Libraries/seekfree_libraries/zf_eru_dma.d \
libraries/Libraries/seekfree_libraries/zf_gpio.d \
libraries/Libraries/seekfree_libraries/zf_gpt12.d \
libraries/Libraries/seekfree_libraries/zf_gtm_pwm.d \
libraries/Libraries/seekfree_libraries/zf_spi.d \
libraries/Libraries/seekfree_libraries/zf_stm_systick.d \
libraries/Libraries/seekfree_libraries/zf_uart.d \
libraries/Libraries/seekfree_libraries/zf_vadc.d 

OBJS += \
libraries/Libraries/seekfree_libraries/zf_ccu6_pit.o \
libraries/Libraries/seekfree_libraries/zf_eeprom.o \
libraries/Libraries/seekfree_libraries/zf_eru.o \
libraries/Libraries/seekfree_libraries/zf_eru_dma.o \
libraries/Libraries/seekfree_libraries/zf_gpio.o \
libraries/Libraries/seekfree_libraries/zf_gpt12.o \
libraries/Libraries/seekfree_libraries/zf_gtm_pwm.o \
libraries/Libraries/seekfree_libraries/zf_spi.o \
libraries/Libraries/seekfree_libraries/zf_stm_systick.o \
libraries/Libraries/seekfree_libraries/zf_uart.o \
libraries/Libraries/seekfree_libraries/zf_vadc.o 


# Each subdirectory must supply rules for building sources it contributes
libraries/Libraries/seekfree_libraries/zf_ccu6_pit.src: ../libraries/Libraries/seekfree_libraries/zf_ccu6_pit.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_ccu6_pit.o: libraries/Libraries/seekfree_libraries/zf_ccu6_pit.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_eeprom.src: ../libraries/Libraries/seekfree_libraries/zf_eeprom.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_eeprom.o: libraries/Libraries/seekfree_libraries/zf_eeprom.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_eru.src: ../libraries/Libraries/seekfree_libraries/zf_eru.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_eru.o: libraries/Libraries/seekfree_libraries/zf_eru.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_eru_dma.src: ../libraries/Libraries/seekfree_libraries/zf_eru_dma.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_eru_dma.o: libraries/Libraries/seekfree_libraries/zf_eru_dma.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_gpio.src: ../libraries/Libraries/seekfree_libraries/zf_gpio.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_gpio.o: libraries/Libraries/seekfree_libraries/zf_gpio.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_gpt12.src: ../libraries/Libraries/seekfree_libraries/zf_gpt12.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_gpt12.o: libraries/Libraries/seekfree_libraries/zf_gpt12.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_gtm_pwm.src: ../libraries/Libraries/seekfree_libraries/zf_gtm_pwm.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_gtm_pwm.o: libraries/Libraries/seekfree_libraries/zf_gtm_pwm.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_spi.src: ../libraries/Libraries/seekfree_libraries/zf_spi.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_spi.o: libraries/Libraries/seekfree_libraries/zf_spi.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_stm_systick.src: ../libraries/Libraries/seekfree_libraries/zf_stm_systick.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_stm_systick.o: libraries/Libraries/seekfree_libraries/zf_stm_systick.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_uart.src: ../libraries/Libraries/seekfree_libraries/zf_uart.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_uart.o: libraries/Libraries/seekfree_libraries/zf_uart.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_vadc.src: ../libraries/Libraries/seekfree_libraries/zf_vadc.c libraries/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_libraries/zf_vadc.o: libraries/Libraries/seekfree_libraries/zf_vadc.src libraries/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-libraries-2f-Libraries-2f-seekfree_libraries

clean-libraries-2f-Libraries-2f-seekfree_libraries:
	-$(RM) libraries/Libraries/seekfree_libraries/zf_ccu6_pit.d libraries/Libraries/seekfree_libraries/zf_ccu6_pit.o libraries/Libraries/seekfree_libraries/zf_ccu6_pit.src libraries/Libraries/seekfree_libraries/zf_eeprom.d libraries/Libraries/seekfree_libraries/zf_eeprom.o libraries/Libraries/seekfree_libraries/zf_eeprom.src libraries/Libraries/seekfree_libraries/zf_eru.d libraries/Libraries/seekfree_libraries/zf_eru.o libraries/Libraries/seekfree_libraries/zf_eru.src libraries/Libraries/seekfree_libraries/zf_eru_dma.d libraries/Libraries/seekfree_libraries/zf_eru_dma.o libraries/Libraries/seekfree_libraries/zf_eru_dma.src libraries/Libraries/seekfree_libraries/zf_gpio.d libraries/Libraries/seekfree_libraries/zf_gpio.o libraries/Libraries/seekfree_libraries/zf_gpio.src libraries/Libraries/seekfree_libraries/zf_gpt12.d libraries/Libraries/seekfree_libraries/zf_gpt12.o libraries/Libraries/seekfree_libraries/zf_gpt12.src libraries/Libraries/seekfree_libraries/zf_gtm_pwm.d libraries/Libraries/seekfree_libraries/zf_gtm_pwm.o libraries/Libraries/seekfree_libraries/zf_gtm_pwm.src libraries/Libraries/seekfree_libraries/zf_spi.d libraries/Libraries/seekfree_libraries/zf_spi.o libraries/Libraries/seekfree_libraries/zf_spi.src libraries/Libraries/seekfree_libraries/zf_stm_systick.d libraries/Libraries/seekfree_libraries/zf_stm_systick.o libraries/Libraries/seekfree_libraries/zf_stm_systick.src libraries/Libraries/seekfree_libraries/zf_uart.d libraries/Libraries/seekfree_libraries/zf_uart.o libraries/Libraries/seekfree_libraries/zf_uart.src libraries/Libraries/seekfree_libraries/zf_vadc.d libraries/Libraries/seekfree_libraries/zf_vadc.o libraries/Libraries/seekfree_libraries/zf_vadc.src

.PHONY: clean-libraries-2f-Libraries-2f-seekfree_libraries

