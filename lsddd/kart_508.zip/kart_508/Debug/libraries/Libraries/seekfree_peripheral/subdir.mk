################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.c \
../libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.c 

COMPILED_SRCS += \
libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src \
libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src 

C_DEPS += \
libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.d \
libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.d 

OBJS += \
libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.o \
libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.o 


# Each subdirectory must supply rules for building sources it contributes
libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src: ../libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.c libraries/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.o: libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src libraries/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-libraries-2f-Libraries-2f-seekfree_peripheral

clean-libraries-2f-Libraries-2f-seekfree_peripheral:
	-$(RM) libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.d libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.o libraries/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.d libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.o libraries/Libraries/seekfree_peripheral/SEEKFREE_7725.src libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.d libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.o libraries/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.d libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.o libraries/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.d libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.o libraries/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.d libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.o libraries/Libraries/seekfree_peripheral/SEEKFREE_FONT.src libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.d libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.o libraries/Libraries/seekfree_peripheral/SEEKFREE_FUN.src libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.d libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.o libraries/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.d libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.o libraries/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.d libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.o libraries/Libraries/seekfree_peripheral/SEEKFREE_IIC.src libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.d libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.o libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.d libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.o libraries/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.d libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.o libraries/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.d libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.o libraries/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.d libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.o libraries/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.d libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.o libraries/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.d libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.o libraries/Libraries/seekfree_peripheral/SEEKFREE_OLED.src libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.d libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.o libraries/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.d libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.o libraries/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.d libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.o libraries/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src

.PHONY: clean-libraries-2f-Libraries-2f-seekfree_peripheral

