zf_assert.o :	../code/Libraries/seekfree_libraries/common/zf_assert.c
../code/Libraries/seekfree_libraries/common/zf_assert.c :
zf_assert.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
zf_assert.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
zf_assert.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\user\TC264_config.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\user\TC264_config.h" :
zf_assert.o :	..\code\Libraries\seekfree_libraries\common\zf_assert.h
..\code\Libraries\seekfree_libraries\common\zf_assert.h :
zf_assert.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Ifx_Types.h" :
zf_assert.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
zf_assert.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
zf_assert.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
zf_assert.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
zf_assert.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Platform_Types.h" :
zf_assert.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h" :
