zf_device_icm20602.o :	../libraries/zf_device/zf_device_icm20602.c
../libraries/zf_device/zf_device_icm20602.c :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_common\zf_common_debug.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_common\zf_common_debug.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_common\zf_common_typedef.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_common\zf_common_typedef.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
zf_device_icm20602.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Platform_Types.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\Ifx_TypesTasking.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_common\zf_common_interrupt.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_common\zf_common_interrupt.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_delay.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_delay.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_spi.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_spi.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_gpio.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_gpio.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_soft_iic.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_soft_iic.h" :
zf_device_icm20602.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_gpio.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\zf_driver\zf_driver_gpio.h" :
zf_device_icm20602.o :	..\libraries\zf_device\zf_device_icm20602.h
..\libraries\zf_device\zf_device_icm20602.h :
