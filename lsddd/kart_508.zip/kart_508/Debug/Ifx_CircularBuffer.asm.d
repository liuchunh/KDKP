Ifx_CircularBuffer.asm.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/DataHandling/Ifx_CircularBuffer.asm.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/DataHandling/Ifx_CircularBuffer.asm.c :
Ifx_CircularBuffer.asm.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Lib\DataHandling\Ifx_CircularBuffer.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Lib\DataHandling\Ifx_CircularBuffer.h :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Ifx_CircularBuffer.asm.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Ifx_CircularBuffer.asm.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
