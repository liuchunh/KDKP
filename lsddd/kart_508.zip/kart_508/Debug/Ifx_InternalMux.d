Ifx_InternalMux.o :	../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/InternalMux/Ifx_InternalMux.c
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/InternalMux/Ifx_InternalMux.c :
Ifx_InternalMux.o :	..\code\Libraries\infineon_libraries\iLLD\TC26B\Tricore\_Lib\InternalMux\Ifx_InternalMux.h
..\code\Libraries\infineon_libraries\iLLD\TC26B\Tricore\_Lib\InternalMux\Ifx_InternalMux.h :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\user\TC264_config.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\user\TC264_config.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Ifx_InternalMux.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Ifx_InternalMux.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\guandao_425\\code\\Libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
