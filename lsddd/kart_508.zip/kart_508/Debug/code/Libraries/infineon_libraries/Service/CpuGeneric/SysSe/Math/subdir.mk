################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.c 

COMPILED_SRCS += \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src 

C_DEPS += \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.d 

OBJS += \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Math

clean-code-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Math:
	-$(RM) code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Cf32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_Crc.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_BitReverseTable.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_FftF32_TwiddleTable.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_IntegralF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LowPassPt1F32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutAtan2F32_Table.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLSincosF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutLinearF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_LutSincosF32_Table.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_RampF32.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_BlackmanHarrisTable.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_WndF32_HannTable.src

.PHONY: clean-code-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Math

