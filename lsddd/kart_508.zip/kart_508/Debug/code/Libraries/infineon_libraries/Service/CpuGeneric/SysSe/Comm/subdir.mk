################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.c \
../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.c 

COMPILED_SRCS += \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.src \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.src 

C_DEPS += \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.d \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.d 

OBJS += \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.o \
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.src: ../code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.c code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.o: code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Comm

clean-code-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Comm:
	-$(RM) code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Console.src code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.d code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.o code/Libraries/infineon_libraries/Service/CpuGeneric/SysSe/Comm/Ifx_Shell.src

.PHONY: clean-code-2f-Libraries-2f-infineon_libraries-2f-Service-2f-CpuGeneric-2f-SysSe-2f-Comm

