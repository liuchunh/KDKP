################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.c 

COMPILED_SRCS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.src 

C_DEPS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.d 

OBJS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-_Impl

clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-_Impl:
	-$(RM) code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxAsclin_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCcu6_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCif_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxCpu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxDma_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEray_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxFlash_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxGtm_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxI2c_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMsc_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMultican_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPort_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxPsi5_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxQspi_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxScu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSent_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSmu_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxSrc_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxStm_cfg.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxVadc_cfg.src

.PHONY: clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-_Impl

