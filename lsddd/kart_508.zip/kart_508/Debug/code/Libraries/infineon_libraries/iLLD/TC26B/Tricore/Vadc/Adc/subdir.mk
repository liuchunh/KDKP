################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.c 

COMPILED_SRCS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.src 

C_DEPS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.d 

OBJS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-Vadc-2f-Adc

clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-Vadc-2f-Adc:
	-$(RM) code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Adc/IfxVadc_Adc.src

.PHONY: clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-Vadc-2f-Adc

