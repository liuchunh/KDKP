################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.c \
../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.c 

COMPILED_SRCS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.src \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.src 

C_DEPS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.d \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.d 

OBJS += \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.o \
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.src: ../code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.c code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.o: code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-_PinMap

clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-_PinMap:
	-$(RM) code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxAsclin_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCif_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxDsadc_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEray_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxEth_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGpt12_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxGtm_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxI2c_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMsc_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxMultican_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPort_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxPsi5s_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxQspi_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxScu_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSent_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxSmu_PinMap.src code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.d code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.o code/Libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxVadc_PinMap.src

.PHONY: clean-code-2f-Libraries-2f-infineon_libraries-2f-iLLD-2f-TC26B-2f-Tricore-2f-_PinMap

