################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.c \
../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.c \
../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.c \
../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.c 

COMPILED_SRCS += \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.src \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.src \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.src \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.src 

C_DEPS += \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.d \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.d \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.d \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.d 

OBJS += \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.o \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.o \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.o \
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.src: ../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.c code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.o: code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.src code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.src: ../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.c code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.o: code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.src code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.src: ../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.c code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.o: code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.src code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.src: ../code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.c code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.o: code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.src code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-infineon_libraries-2f-Infra-2f-Platform-2f-Tricore-2f-Compilers

clean-code-2f-Libraries-2f-infineon_libraries-2f-Infra-2f-Platform-2f-Tricore-2f-Compilers:
	-$(RM) code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.d code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.o code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerDcc.src code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.d code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.o code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.src code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.d code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.o code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGnuc.src code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.d code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.o code/Libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerTasking.src

.PHONY: clean-code-2f-Libraries-2f-infineon_libraries-2f-Infra-2f-Platform-2f-Tricore-2f-Compilers

