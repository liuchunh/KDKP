################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/seekfree_libraries/zf_ccu6_pit.c \
../code/Libraries/seekfree_libraries/zf_eeprom.c \
../code/Libraries/seekfree_libraries/zf_eru.c \
../code/Libraries/seekfree_libraries/zf_eru_dma.c \
../code/Libraries/seekfree_libraries/zf_gpio.c \
../code/Libraries/seekfree_libraries/zf_gpt12.c \
../code/Libraries/seekfree_libraries/zf_gtm_pwm.c \
../code/Libraries/seekfree_libraries/zf_spi.c \
../code/Libraries/seekfree_libraries/zf_stm_systick.c \
../code/Libraries/seekfree_libraries/zf_uart.c \
../code/Libraries/seekfree_libraries/zf_vadc.c 

COMPILED_SRCS += \
code/Libraries/seekfree_libraries/zf_ccu6_pit.src \
code/Libraries/seekfree_libraries/zf_eeprom.src \
code/Libraries/seekfree_libraries/zf_eru.src \
code/Libraries/seekfree_libraries/zf_eru_dma.src \
code/Libraries/seekfree_libraries/zf_gpio.src \
code/Libraries/seekfree_libraries/zf_gpt12.src \
code/Libraries/seekfree_libraries/zf_gtm_pwm.src \
code/Libraries/seekfree_libraries/zf_spi.src \
code/Libraries/seekfree_libraries/zf_stm_systick.src \
code/Libraries/seekfree_libraries/zf_uart.src \
code/Libraries/seekfree_libraries/zf_vadc.src 

C_DEPS += \
code/Libraries/seekfree_libraries/zf_ccu6_pit.d \
code/Libraries/seekfree_libraries/zf_eeprom.d \
code/Libraries/seekfree_libraries/zf_eru.d \
code/Libraries/seekfree_libraries/zf_eru_dma.d \
code/Libraries/seekfree_libraries/zf_gpio.d \
code/Libraries/seekfree_libraries/zf_gpt12.d \
code/Libraries/seekfree_libraries/zf_gtm_pwm.d \
code/Libraries/seekfree_libraries/zf_spi.d \
code/Libraries/seekfree_libraries/zf_stm_systick.d \
code/Libraries/seekfree_libraries/zf_uart.d \
code/Libraries/seekfree_libraries/zf_vadc.d 

OBJS += \
code/Libraries/seekfree_libraries/zf_ccu6_pit.o \
code/Libraries/seekfree_libraries/zf_eeprom.o \
code/Libraries/seekfree_libraries/zf_eru.o \
code/Libraries/seekfree_libraries/zf_eru_dma.o \
code/Libraries/seekfree_libraries/zf_gpio.o \
code/Libraries/seekfree_libraries/zf_gpt12.o \
code/Libraries/seekfree_libraries/zf_gtm_pwm.o \
code/Libraries/seekfree_libraries/zf_spi.o \
code/Libraries/seekfree_libraries/zf_stm_systick.o \
code/Libraries/seekfree_libraries/zf_uart.o \
code/Libraries/seekfree_libraries/zf_vadc.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/seekfree_libraries/zf_ccu6_pit.src: ../code/Libraries/seekfree_libraries/zf_ccu6_pit.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_ccu6_pit.o: code/Libraries/seekfree_libraries/zf_ccu6_pit.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_eeprom.src: ../code/Libraries/seekfree_libraries/zf_eeprom.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_eeprom.o: code/Libraries/seekfree_libraries/zf_eeprom.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_eru.src: ../code/Libraries/seekfree_libraries/zf_eru.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_eru.o: code/Libraries/seekfree_libraries/zf_eru.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_eru_dma.src: ../code/Libraries/seekfree_libraries/zf_eru_dma.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_eru_dma.o: code/Libraries/seekfree_libraries/zf_eru_dma.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_gpio.src: ../code/Libraries/seekfree_libraries/zf_gpio.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_gpio.o: code/Libraries/seekfree_libraries/zf_gpio.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_gpt12.src: ../code/Libraries/seekfree_libraries/zf_gpt12.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_gpt12.o: code/Libraries/seekfree_libraries/zf_gpt12.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_gtm_pwm.src: ../code/Libraries/seekfree_libraries/zf_gtm_pwm.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_gtm_pwm.o: code/Libraries/seekfree_libraries/zf_gtm_pwm.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_spi.src: ../code/Libraries/seekfree_libraries/zf_spi.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_spi.o: code/Libraries/seekfree_libraries/zf_spi.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_stm_systick.src: ../code/Libraries/seekfree_libraries/zf_stm_systick.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_stm_systick.o: code/Libraries/seekfree_libraries/zf_stm_systick.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_uart.src: ../code/Libraries/seekfree_libraries/zf_uart.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_uart.o: code/Libraries/seekfree_libraries/zf_uart.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/zf_vadc.src: ../code/Libraries/seekfree_libraries/zf_vadc.c code/Libraries/seekfree_libraries/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/zf_vadc.o: code/Libraries/seekfree_libraries/zf_vadc.src code/Libraries/seekfree_libraries/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-seekfree_libraries

clean-code-2f-Libraries-2f-seekfree_libraries:
	-$(RM) code/Libraries/seekfree_libraries/zf_ccu6_pit.d code/Libraries/seekfree_libraries/zf_ccu6_pit.o code/Libraries/seekfree_libraries/zf_ccu6_pit.src code/Libraries/seekfree_libraries/zf_eeprom.d code/Libraries/seekfree_libraries/zf_eeprom.o code/Libraries/seekfree_libraries/zf_eeprom.src code/Libraries/seekfree_libraries/zf_eru.d code/Libraries/seekfree_libraries/zf_eru.o code/Libraries/seekfree_libraries/zf_eru.src code/Libraries/seekfree_libraries/zf_eru_dma.d code/Libraries/seekfree_libraries/zf_eru_dma.o code/Libraries/seekfree_libraries/zf_eru_dma.src code/Libraries/seekfree_libraries/zf_gpio.d code/Libraries/seekfree_libraries/zf_gpio.o code/Libraries/seekfree_libraries/zf_gpio.src code/Libraries/seekfree_libraries/zf_gpt12.d code/Libraries/seekfree_libraries/zf_gpt12.o code/Libraries/seekfree_libraries/zf_gpt12.src code/Libraries/seekfree_libraries/zf_gtm_pwm.d code/Libraries/seekfree_libraries/zf_gtm_pwm.o code/Libraries/seekfree_libraries/zf_gtm_pwm.src code/Libraries/seekfree_libraries/zf_spi.d code/Libraries/seekfree_libraries/zf_spi.o code/Libraries/seekfree_libraries/zf_spi.src code/Libraries/seekfree_libraries/zf_stm_systick.d code/Libraries/seekfree_libraries/zf_stm_systick.o code/Libraries/seekfree_libraries/zf_stm_systick.src code/Libraries/seekfree_libraries/zf_uart.d code/Libraries/seekfree_libraries/zf_uart.o code/Libraries/seekfree_libraries/zf_uart.src code/Libraries/seekfree_libraries/zf_vadc.d code/Libraries/seekfree_libraries/zf_vadc.o code/Libraries/seekfree_libraries/zf_vadc.src

.PHONY: clean-code-2f-Libraries-2f-seekfree_libraries

