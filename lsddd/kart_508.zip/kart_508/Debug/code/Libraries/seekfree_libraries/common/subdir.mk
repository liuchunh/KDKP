################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.c \
../code/Libraries/seekfree_libraries/common/common.c \
../code/Libraries/seekfree_libraries/common/zf_assert.c 

COMPILED_SRCS += \
code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src \
code/Libraries/seekfree_libraries/common/common.src \
code/Libraries/seekfree_libraries/common/zf_assert.src 

C_DEPS += \
code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.d \
code/Libraries/seekfree_libraries/common/common.d \
code/Libraries/seekfree_libraries/common/zf_assert.d 

OBJS += \
code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.o \
code/Libraries/seekfree_libraries/common/common.o \
code/Libraries/seekfree_libraries/common/zf_assert.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src: ../code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.c code/Libraries/seekfree_libraries/common/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.o: code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src code/Libraries/seekfree_libraries/common/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/common/common.src: ../code/Libraries/seekfree_libraries/common/common.c code/Libraries/seekfree_libraries/common/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/common/common.o: code/Libraries/seekfree_libraries/common/common.src code/Libraries/seekfree_libraries/common/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_libraries/common/zf_assert.src: ../code/Libraries/seekfree_libraries/common/zf_assert.c code/Libraries/seekfree_libraries/common/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_libraries/common/zf_assert.o: code/Libraries/seekfree_libraries/common/zf_assert.src code/Libraries/seekfree_libraries/common/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-seekfree_libraries-2f-common

clean-code-2f-Libraries-2f-seekfree_libraries-2f-common:
	-$(RM) code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.d code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.o code/Libraries/seekfree_libraries/common/SEEKFREE_PRINTF.src code/Libraries/seekfree_libraries/common/common.d code/Libraries/seekfree_libraries/common/common.o code/Libraries/seekfree_libraries/common/common.src code/Libraries/seekfree_libraries/common/zf_assert.d code/Libraries/seekfree_libraries/common/zf_assert.o code/Libraries/seekfree_libraries/common/zf_assert.src

.PHONY: clean-code-2f-Libraries-2f-seekfree_libraries-2f-common

