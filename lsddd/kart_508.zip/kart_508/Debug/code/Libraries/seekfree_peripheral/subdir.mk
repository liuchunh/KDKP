################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_7725.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_FONT.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_FUN.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_IIC.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_OLED.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.c \
../code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.c 

COMPILED_SRCS += \
code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src \
code/Libraries/seekfree_peripheral/SEEKFREE_7725.src \
code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src \
code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src \
code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src \
code/Libraries/seekfree_peripheral/SEEKFREE_FONT.src \
code/Libraries/seekfree_peripheral/SEEKFREE_FUN.src \
code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src \
code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src \
code/Libraries/seekfree_peripheral/SEEKFREE_IIC.src \
code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src \
code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src \
code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src \
code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src \
code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src \
code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src \
code/Libraries/seekfree_peripheral/SEEKFREE_OLED.src \
code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src \
code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src \
code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src 

C_DEPS += \
code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.d \
code/Libraries/seekfree_peripheral/SEEKFREE_7725.d \
code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.d \
code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.d \
code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.d \
code/Libraries/seekfree_peripheral/SEEKFREE_FONT.d \
code/Libraries/seekfree_peripheral/SEEKFREE_FUN.d \
code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.d \
code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.d \
code/Libraries/seekfree_peripheral/SEEKFREE_IIC.d \
code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.d \
code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.d \
code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.d \
code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.d \
code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.d \
code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.d \
code/Libraries/seekfree_peripheral/SEEKFREE_OLED.d \
code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.d \
code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.d \
code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.d 

OBJS += \
code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.o \
code/Libraries/seekfree_peripheral/SEEKFREE_7725.o \
code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.o \
code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.o \
code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.o \
code/Libraries/seekfree_peripheral/SEEKFREE_FONT.o \
code/Libraries/seekfree_peripheral/SEEKFREE_FUN.o \
code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.o \
code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.o \
code/Libraries/seekfree_peripheral/SEEKFREE_IIC.o \
code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.o \
code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.o \
code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.o \
code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.o \
code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.o \
code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.o \
code/Libraries/seekfree_peripheral/SEEKFREE_OLED.o \
code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.o \
code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.o \
code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.o 


# Each subdirectory must supply rules for building sources it contributes
code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.o: code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_7725.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_7725.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_7725.o: code/Libraries/seekfree_peripheral/SEEKFREE_7725.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.o: code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.o: code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.o: code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_FONT.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_FONT.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_FONT.o: code/Libraries/seekfree_peripheral/SEEKFREE_FONT.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_FUN.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_FUN.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_FUN.o: code/Libraries/seekfree_peripheral/SEEKFREE_FUN.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.o: code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.o: code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_IIC.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_IIC.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_IIC.o: code/Libraries/seekfree_peripheral/SEEKFREE_IIC.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.o: code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.o: code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.o: code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.o: code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.o: code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.o: code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_OLED.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_OLED.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_OLED.o: code/Libraries/seekfree_peripheral/SEEKFREE_OLED.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.o: code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.o: code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src: ../code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.c code/Libraries/seekfree_peripheral/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/18905/Desktop/���ܳ�/����ԽҰ/guandao_425/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=2 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.o: code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src code/Libraries/seekfree_peripheral/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code-2f-Libraries-2f-seekfree_peripheral

clean-code-2f-Libraries-2f-seekfree_peripheral:
	-$(RM) code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.d code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.o code/Libraries/seekfree_peripheral/SEEKFREE_18TFT.src code/Libraries/seekfree_peripheral/SEEKFREE_7725.d code/Libraries/seekfree_peripheral/SEEKFREE_7725.o code/Libraries/seekfree_peripheral/SEEKFREE_7725.src code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.d code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.o code/Libraries/seekfree_peripheral/SEEKFREE_7725_UART.src code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.d code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.o code/Libraries/seekfree_peripheral/SEEKFREE_ABSOLUTE_ENCODER.src code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.d code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.o code/Libraries/seekfree_peripheral/SEEKFREE_BLUETOOTH_CH9141.src code/Libraries/seekfree_peripheral/SEEKFREE_FONT.d code/Libraries/seekfree_peripheral/SEEKFREE_FONT.o code/Libraries/seekfree_peripheral/SEEKFREE_FONT.src code/Libraries/seekfree_peripheral/SEEKFREE_FUN.d code/Libraries/seekfree_peripheral/SEEKFREE_FUN.o code/Libraries/seekfree_peripheral/SEEKFREE_FUN.src code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.d code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.o code/Libraries/seekfree_peripheral/SEEKFREE_GPS_TAU1201.src code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.d code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.o code/Libraries/seekfree_peripheral/SEEKFREE_ICM20602.src code/Libraries/seekfree_peripheral/SEEKFREE_IIC.d code/Libraries/seekfree_peripheral/SEEKFREE_IIC.o code/Libraries/seekfree_peripheral/SEEKFREE_IIC.src code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.d code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.o code/Libraries/seekfree_peripheral/SEEKFREE_IPS114_SPI.src code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.d code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.o code/Libraries/seekfree_peripheral/SEEKFREE_IPS200_PARALLEL8.src code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.d code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.o code/Libraries/seekfree_peripheral/SEEKFREE_L3G4200D.src code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.d code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.o code/Libraries/seekfree_peripheral/SEEKFREE_MMA8451.src code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.d code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.o code/Libraries/seekfree_peripheral/SEEKFREE_MPU6050.src code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.d code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.o code/Libraries/seekfree_peripheral/SEEKFREE_MT9V03X.src code/Libraries/seekfree_peripheral/SEEKFREE_OLED.d code/Libraries/seekfree_peripheral/SEEKFREE_OLED.o code/Libraries/seekfree_peripheral/SEEKFREE_OLED.src code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.d code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.o code/Libraries/seekfree_peripheral/SEEKFREE_RDA5807.src code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.d code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.o code/Libraries/seekfree_peripheral/SEEKFREE_VIRSCO.src code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.d code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.o code/Libraries/seekfree_peripheral/SEEKFREE_WIRELESS.src

.PHONY: clean-code-2f-Libraries-2f-seekfree_peripheral

