Ifx_AngleTrkF32.o :	../libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.c
../libraries/infineon_libraries/Service/CpuGeneric/SysSe/Math/Ifx_AngleTrkF32.c :
Ifx_AngleTrkF32.o :	..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Math\Ifx_AngleTrkF32.h
..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Math\Ifx_AngleTrkF32.h :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_Pos.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_Pos.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Ifx_AngleTrkF32.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Math\Ifx_LowPassPt1F32.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Math\Ifx_LowPassPt1F32.h" :
Ifx_AngleTrkF32.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
Ifx_AngleTrkF32.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
Ifx_AngleTrkF32.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Ifx_AngleTrkF32.o :	..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Math\Ifx_LutAtan2F32.h
..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Math\Ifx_LutAtan2F32.h :
Ifx_AngleTrkF32.o :	..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Math\Ifx_Lut.h
..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Math\Ifx_Lut.h :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Ifx_AngleTrkF32.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
