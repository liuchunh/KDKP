IfxEmem_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxEmem_cfg.c :
IfxEmem_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxEmem_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxEmem_cfg.h :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxEmem_cfg.o :	"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"F:\aurixide\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxEmem_reg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxEmem_reg.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxEmem_regdef.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxEmem_regdef.h" :
IfxEmem_cfg.o :	"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\18905\\Desktop\\���ܳ�\\����ԽҰ\\kart_508\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
