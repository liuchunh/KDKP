del release\obj\*.*      /q
del release\list\*.*     /q
del release\*.*          /q


