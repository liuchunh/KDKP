/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
��ƽ    ̨�������������ܿƼ�LPC546XX���İ�
����    д��CHIUSIR
����    ע��
�������汾��V1.0
�������¡�2017��10��22��
�������Ϣ�ο����е�ַ��
����    վ��http://www.lqist.cn
���Ա����̡�http://shop36265907.taobao.com
���������䡿chiusir@163.com
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
#include "include.h"

/*
                   _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            @@@�C@@       @@@@BUG
*/
/**
  * @brief    IIC���Ÿ��ù�������
  *
  * @param    
  *
  * @return   
  *
  * @note     �����������IIC8������ ���Ҫʹ������IIC�ӿڣ� ����ʹ��MCUXpresso �����������ã����ɴ�����Ƽ���
  *
  * @example  
  *
  * @date     2019/5/8 ������
  */
void IIC8_InitPins(void)
{  
    /* Enables the clock for the IOCON block. 0 = Disable; 1 = Enable.: 0x01u */
    CLOCK_EnableClock(kCLOCK_Iocon);

    const uint32_t port1_pin17_config = (/* Pin is configured as FC8_RXD_SDA_MOSI */
                                         IOCON_PIO_FUNC2 |
                                         /* Selects pull-up function */
                                         IOCON_PIO_MODE_PULLUP |
                                         /* Input function is not inverted */
                                         IOCON_PIO_INV_DI |
                                         /* Enables digital function */
                                         IOCON_PIO_DIGITAL_EN |
                                         /* Input filter disabled */
                                         IOCON_PIO_INPFILT_OFF |
                                         /* Standard mode, output slew rate control is enabled */
                                         IOCON_PIO_SLEW_STANDARD |
                                         /* Open drain is enabled */
                                         IOCON_PIO_OPENDRAIN_EN);
    /* PORT1 PIN17 (coords: N12) is configured as FC8_RXD_SDA_MOSI */
    IOCON_PinMuxSet(IOCON, 1U, 17U, port1_pin17_config);

    const uint32_t port1_pin18_config = (/* Pin is configured as FC8_TXD_SCL_MISO */
                                         IOCON_PIO_FUNC2 |
                                         /* Selects pull-up function */
                                         IOCON_PIO_MODE_PULLUP |
                                         /* Input function is not inverted */
                                         IOCON_PIO_INV_DI |
                                         /* Enables digital function */
                                         IOCON_PIO_DIGITAL_EN |
                                         /* Input filter disabled */
                                         IOCON_PIO_INPFILT_OFF |
                                         /* Standard mode, output slew rate control is enabled */
                                         IOCON_PIO_SLEW_STANDARD |
                                         /* Open drain is enabled */
                                         IOCON_PIO_OPENDRAIN_EN);
    /* PORT1 PIN18 (coords: D1) is configured as FC8_TXD_SCL_MISO */
    IOCON_PinMuxSet(IOCON, 1U, 18U, port1_pin18_config);
}

/**
  * @brief    IIC8��ʼ�� 
  *
  * @param    
  *
  * @return   
  *
  * @note     ���������IIC8   Ҫʹ������IIC���������޸�
  *
  * @example  
  *
  * @date     2019/5/8 ������
  */
void I2C8_Init(uint32_t baudrate)
{
    
    i2c_master_config_t masterConfig;
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* attach 12 MHz clock to FLEXCOMM8 (I2C master) */
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM8);

    /* reset FLEXCOMM for I2C */
    RESET_PeripheralReset(kFC8_RST_SHIFT_RSTn);
    
    IIC8_InitPins();    //ʹ��  IIC8   SDA��port1_pin17     SCL��port1_pin18
    /*
     * masterConfig.debugEnable = false;
     * masterConfig.ignoreAck   = false;
     * masterConfig.pinConfig   = kI2C_2PinOpenDrain;
     * masterConfig.baudRate_Bps            = 100000U;
     * masterConfig.busIdleTimeout_ns       = 0;
     * masterConfig.pinLowTimeout_ns        = 0;
     * masterConfig.sdaGlitchFilterWidth_ns = 0;
     * masterConfig.sclGlitchFilterWidth_ns = 0;
     */
    I2C_MasterGetDefaultConfig(&masterConfig);

    /* Change the default baudrate configuration */
    masterConfig.baudRate_Bps = baudrate;
    
    /* Initialize the I2C master peripheral */
    I2C_MasterInit(I2C8, &masterConfig, I2C_MASTER_CLOCK_FREQUENCY);

}


/**
  * @brief    IIC���Ĵ���
  *
  * @param    base       �� IIC����ַ
  * @param    address    �� IIC������ַ ����λ
  * @param    reg        �� Ҫ���ļĴ���
  * @param    val        �� ָ���Ŷ�ȡֵ�ĵ�ַ
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/8 ������
  */
status_t IIC_Read_Reg(I2C_Type *base, uint8_t address, uint8_t reg, uint8_t * val)
{

    status_t reVal = kStatus_Fail;
    uint8_t buf[1];
    buf[0] = reg;
    if (kStatus_Success == I2C_MasterStart(base, address, kI2C_Write))
    {
        reVal = I2C_MasterWriteBlocking(base, buf, 1, kI2C_TransferNoStopFlag);
        if (reVal != kStatus_Success)
        {
            return -1;
        }

        reVal = I2C_MasterRepeatedStart(base, address, kI2C_Read);
        if (reVal != kStatus_Success)
        {
            return -1;
        }

        reVal = I2C_MasterReadBlocking(base, val, 1, 0);
        if (reVal != kStatus_Success)
        {
            return -1;
        }

        reVal = I2C_MasterStop(base);
        if (reVal != kStatus_Success)
        {
            return -1;
        }
    }
    return reVal;
}

/**
  * @brief    IICд�Ĵ���
  *
  * @param    base       �� IIC����ַ
  * @param    address    �� IIC������ַ ����λ
  * @param    reg        �� Ҫ���ļĴ���
  * @param    val        �� Ҫд��ֵ
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/8 ������
  */
status_t IIC_Write_Reg(I2C_Type *base, uint8_t address, uint8_t reg, uint8_t val)
{
    status_t reVal = kStatus_Fail;
    uint8_t buf[1];
    buf[0] = reg;
    if (kStatus_Success == I2C_MasterStart(base, address, kI2C_Write))
    {
        /* subAddress = 0x01, data = g_master_txBuff - write to slave.
          start + slaveaddress(w) + subAddress + length of data buffer + data buffer + stop*/
        reVal = I2C_MasterWriteBlocking(base, buf, 1, kI2C_TransferNoStopFlag);
        if (reVal != kStatus_Success)
        {
            return kStatus_Fail;
        }
        buf[0] = val;
        reVal = I2C_MasterWriteBlocking(base, buf, 1, 0);
        if (reVal != kStatus_Success)
        {
            return kStatus_Fail;
        }

        reVal = I2C_MasterStop(base);
        if (reVal != kStatus_Success)
        {
            return kStatus_Fail;
        }
    }
    return reVal;

}


/**
  * @brief    IIC���Ĵ���
  *
  * @param    base       �� IIC����ַ
  * @param    address    �� IIC������ַ ����λ
  * @param    reg        �� Ҫ���ļĴ���
  * @param    buff       �� ָ���Ŷ�ȡֵ���׵�ַ
  * @param    len        �� ��ȡ����
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/8 ������
  */
status_t IIC_Read_Buff(I2C_Type *base, uint8_t address, uint8_t reg, uint8_t *buff, uint8_t len)
{

    status_t reVal = kStatus_Fail;
    uint8_t buf[1];
    buf[0] = reg;
    if (kStatus_Success == I2C_MasterStart(base, address, kI2C_Write))
    {
        reVal = I2C_MasterWriteBlocking(base, buf, 1, kI2C_TransferNoStopFlag);
        if (reVal != kStatus_Success)
        {
            return -1;
        }

        reVal = I2C_MasterRepeatedStart(base, address, kI2C_Read);
        if (reVal != kStatus_Success)
        {
            
            return -1;
        }

        reVal = I2C_MasterReadBlocking(base, buff, len, 0);
        if (reVal != kStatus_Success)
        {
            return -1;
        }

        reVal = I2C_MasterStop(base);
        if (reVal != kStatus_Success)
        {
            return -1;
        }
    }
    return reVal;
}


/**
  * @brief    IICд�Ĵ���
  *
  * @param    base       �� IIC����ַ
  * @param    address    �� IIC������ַ ����λ
  * @param    reg        �� Ҫ���ļĴ���
  * @param    buff       �� ָ��Ҫд�����ݵ��׵�ַ
  * @param    len        �� д����
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/8 ������
  */
status_t IIC_Write_Buff(I2C_Type *base, uint8_t address, uint8_t reg, uint8_t * buff, uint8_t len)
{
    status_t reVal = kStatus_Fail;
    uint8_t buf[1];
    buf[0] = reg;
    if (kStatus_Success == I2C_MasterStart(base, address, kI2C_Write))
    {
        /* subAddress = 0x01, data = g_master_txBuff - write to slave.
          start + slaveaddress(w) + subAddress + length of data buffer + data buffer + stop*/
        reVal = I2C_MasterWriteBlocking(base, buf, 1, kI2C_TransferNoStopFlag);
        if (reVal != kStatus_Success)
        {
            return kStatus_Fail;
        }
        reVal = I2C_MasterWriteBlocking(base, buff, len, 0);
        if (reVal != kStatus_Success)
        {
            return kStatus_Fail;
        }

        reVal = I2C_MasterStop(base);
        if (reVal != kStatus_Success)
        {
            return kStatus_Fail;
        }
    }
    return reVal;

}










