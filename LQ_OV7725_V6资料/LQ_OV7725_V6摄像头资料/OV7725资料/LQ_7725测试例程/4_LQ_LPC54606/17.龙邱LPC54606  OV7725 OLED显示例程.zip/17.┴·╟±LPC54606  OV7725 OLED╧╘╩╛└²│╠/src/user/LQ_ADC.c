/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
��ƽ    ̨�������������ܿƼ�LPC546XX���İ�
����    д��CHIUSIR
����    ע��
�������汾��V1.0
�������¡�2017��10��26��
�������Ϣ�ο����е�ַ��
����    վ��http://www.lqist.cn
���Ա����̡�http://shop36265907.taobao.com
���������䡿chiusir@163.com
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
#include "include.h"

/* �ڲ����� ����ADC��ʼ�� */
static adc_conv_seq_config_t adcConvSeqConfigStruct;    


//----------------------------------------------------------------
//������: ADC_init                                                
//��  ��: ��ʼ��ADC                                               
//��  ��: channel: ADCͨ��                                        
//��  ��: bit    : ADC�ֱ���                                        
//��  ��: ��                                                      
//��  ��: ADC0_Init(ADC0CH0,ADC_12bit);                       
//----------------------------------------------------------------
void ADC0_Init(ADCn_Ch channel,ADC_nbit bit)
{ 
    adc_config_t adcConfigStruct;
    
    
    // SYSCON power.
    POWER_DisablePD(kPDRUNCFG_PD_VDDA);    /* Power on VDDA. */
    POWER_DisablePD(kPDRUNCFG_PD_ADC0);    /* Power on the ADC converter. */
    POWER_DisablePD(kPDRUNCFG_PD_VD2_ANA); /* Power on the analog power supply. */
    POWER_DisablePD(kPDRUNCFG_PD_VREFP);   /* Power on the reference voltage source. */
    
    CLOCK_EnableClock(kCLOCK_Adc0); /* SYSCON->AHBCLKCTRL[0] |= SYSCON_AHBCLKCTRL_ADC0_MASK; */
    
    switch(channel)
    {
      case ADC0CH0: 
        IOCON->PIO[0][10] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH1: 
        IOCON->PIO[0][11] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH2: 
        IOCON->PIO[0][12] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH3: 
        IOCON->PIO[0][15] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH4: 
        IOCON->PIO[0][16] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH5: 
        IOCON->PIO[0][31] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH6: 
        IOCON->PIO[1][0] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH7: 
        IOCON->PIO[2][0] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH8: 
        IOCON->PIO[2][1] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH9: 
        IOCON->PIO[3][21] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH10: 
        IOCON->PIO[3][22] &=~IOCON_PIO_DIGITAL_EN;
        break;
      case ADC0CH11: 
        IOCON->PIO[0][23] &=~IOCON_PIO_DIGITAL_EN;
        break;
      default:
        break;
    }   
    
    if (!ADC_DoSelfCalibration(ADC0))
    {
        assert("ADC SelfCalibration Error!");
        // return;
    }
    
    adcConfigStruct.clockMode = kADC_ClockSynchronousMode; /* Using sync clock source. */
    adcConfigStruct.clockDividerNumber = 3;                /* The divider for sync clock is ?. */
    adcConfigStruct.resolution =(adc_resolution_t)bit;
    adcConfigStruct.enableBypassCalibration = false;
    adcConfigStruct.sampleTimeNumber = 0U;
    ADC_Init(ADC0, &adcConfigStruct);
    
    /* Enable channel 0's conversion in Sequence A. */
    adcConvSeqConfigStruct.channelMask |= (1U << channel); /* Includes channel ?. */
    adcConvSeqConfigStruct.triggerMask = 0U;
    adcConvSeqConfigStruct.triggerPolarity = kADC_TriggerPolarityNegativeEdge;
    adcConvSeqConfigStruct.enableSingleStep = false;
    adcConvSeqConfigStruct.enableSyncBypass = false;
    adcConvSeqConfigStruct.interruptMode = kADC_InterruptForEachSequence;
    
    ADC_SetConvSeqAConfig(ADC0, &adcConvSeqConfigStruct);
    ADC_EnableConvSeqA(ADC0, true); // Enable the conversion sequence B.   
    
    ADC_DoSoftwareTriggerConvSeqA(ADC0);  
    ADC0->SEQ_CTRL[0] |= ADC_SEQ_CTRL_START_MASK;;//��ʼת��
}

/**
  * @brief    ��ȡADC�Ĳ���ֵ
  *
  * @param    channel ��adcͨ��
  *
  * @return   ����ֵ
  *
  * @note     ��
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
uint16_t ADC0_GetResult(ADCn_Ch channel)
{
  adc_result_info_t adcResultInfoStruct;  
  
  ADC0->SEQ_CTRL[0] |= ADC_SEQ_CTRL_START_MASK;//����A����ת��  
  
  /* Wait for the converter to be done. */
  while(!ADC_GetChannelConversionResult(ADC0, channel, &adcResultInfoStruct));
  
  return (adcResultInfoStruct.result);/* Read to clear the status. */
}


/**
  * @brief    ����ADCͨ��
  *
  * @param    ��
  *
  * @return   ��
  *
  * @note     ��
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */

void Test_ADC(void)
{
    char txt[32];
    float batv1, batv2, batv3, batv4, batv5, batv6;
    
    //ADC0��ʼ��
    ADC0_Init(ADC0CH0,ADC_12bit);     //P0_10
    ADC0_Init(ADC0CH3,ADC_12bit);     //P0_15 
    ADC0_Init(ADC0CH4,ADC_12bit);     //P0_16
	ADC0_Init(ADC0CH5,ADC_12bit);     //P0_31
	ADC0_Init(ADC0CH6,ADC_12bit);     //P1_0
    ADC0_Init(ADC0CH11,ADC_12bit);    //P0_23 ĸ�����Ѿ�����������ص�ѹ
	
    //LED��ʼ��
	LED_Init();                         
    
    //UART������ʾ
    UART_Init(UART0,115200);

	printf("����ADC���Գ���\n");
#ifdef OLED
    OLED_Init();
    OLED_CLS();                   //LCD����
    OLED_P8x16Str(4,0,(uint8_t*)"LQ ADC Test Bat");  
#else
    TFTSPI_Init(1);        //LCD��ʼ��  0:����  1������
    TFTSPI_CLS(u16BLUE);   //��ɫ��Ļ	  
    TFTSPI_P16x16Str(0,0,"�����������ܿƼ�",u16RED,u16BLUE);		//�ַ�����ʾ
#endif
    while (1)
    {           
        //����ADCת��
        batv1=ADC0_GetResult(ADC0CH0)*0.000806;             //3.3/4095
        sprintf(txt,"P010: %5.3f V",batv1);
#ifdef OLED
        OLED_P6x8Str(20,2,(u8*)txt);
#else
        TFTSPI_P8X8Str(1,3,txt,u16RED,u16BLUE);
#endif
        printf(txt); 
        
        batv2=ADC0_GetResult(ADC0CH3)*0.000806;             //3.3/4095
        sprintf(txt,"P015: %5.3f V",batv2);
#ifdef OLED
        OLED_P6x8Str(20,3,(u8*)txt);
#else
        TFTSPI_P8X8Str(1,4,txt,u16RED,u16BLUE);
#endif
        printf(txt); 
		
		batv3=ADC0_GetResult(ADC0CH4)*0.000806;             //3.3/4095
        sprintf(txt,"P016: %5.3f V",batv3);
#ifdef OLED
        OLED_P6x8Str(20,4,(u8*)txt);
#else
        TFTSPI_P8X8Str(1,5,txt,u16RED,u16BLUE);
#endif      
        printf(txt);  
		
		batv4=ADC0_GetResult(ADC0CH5)*0.000806;             //3.3/4095
        sprintf(txt,"P031: %5.3f V",batv4);
#ifdef OLED
        OLED_P6x8Str(20,5,(u8*)txt);
#else
        TFTSPI_P8X8Str(1,6,txt,u16RED,u16BLUE);
#endif     
        printf(txt); 
		
		batv5=ADC0_GetResult(ADC0CH6)*0.000806;             //3.3/4095
        sprintf(txt,"P100: %5.3f V",batv5);
#ifdef OLED
        OLED_P6x8Str(20,6,(u8*)txt);
#else
        TFTSPI_P8X8Str(1,7,txt,u16RED,u16BLUE);
#endif     
        printf(txt); 
        
        batv6=ADC0_GetResult(ADC0CH11)*0.0046;         
        sprintf(txt,"P023: %5.3f V",batv6);
#ifdef OLED
        OLED_P6x8Str(20,7,(u8*)txt);
#else
        TFTSPI_P8X8Str(1,8,txt,u16RED,u16BLUE);
#endif   
        printf(txt);
        
        //LED��˸
        LED_Color_Reverse(green);   
        
        //systick�ж���ʱ
        systime.delay_ms(50);
    }
}

