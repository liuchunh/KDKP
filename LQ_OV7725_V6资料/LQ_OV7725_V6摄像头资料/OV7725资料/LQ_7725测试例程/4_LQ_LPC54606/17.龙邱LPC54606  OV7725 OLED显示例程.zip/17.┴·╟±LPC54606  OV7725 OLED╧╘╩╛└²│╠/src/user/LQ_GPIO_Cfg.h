/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
��ƽ    ̨�������������ܿƼ�LPC546XX���İ�
����    д��CHIUSIR
����    ע��
�������汾��V1.0
�������¡�2017��10��22��
�������Ϣ�ο����е�ַ��
����    վ��http://www.lqist.cn
���Ա����̡�http://shop36265907.taobao.com
���������䡿chiusir@163.com
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
#ifndef __GPIO_CFG_H__
#define __GPIO_CFG_H__

/* LQ_546XXE180SYS ��SDRAM/FLASH���İ�����ܽ�

00  01 010 013 014 016 017 022 029 030 031 

10  11  12  13  117 118 122 

20  21  22  25 211 212 214 215 216 217 218 219 220 221 222 223 224 226 227 228 229 230 231

30 31 32 33 34 35 36 37 38 39 310 311 312 313 314 315 316 317 318 319 320 321 322 323 324 326 328 329 330 331 

40 41 42 43 44 45 46 47 48 49 410 411 412 413 414 415 416 

*/

extern const uint32_t PIOFun0_config;  
extern const uint32_t PIOFun1_config;
extern const uint32_t PIOFun2_config;
extern const uint32_t PIOFun3_config;
extern const uint32_t PIOFun4_config;
extern const uint32_t PIOFun5_config;
extern const uint32_t PIOFun6_config;
extern const uint32_t PIOFun7_config;

//����PT0_�Ķ˿�  base->B[port][pin] = output;
#define PT0_0     GPIO->B[0][0]
#define PT0_1     GPIO->B[0][1]
#define PT0_2     GPIO->B[0][2]
#define PT0_3     GPIO->B[0][3]
#define PT0_4     GPIO->B[0][4]
#define PT0_5     GPIO->B[0][5]
#define PT0_6     GPIO->B[0][6]
#define PT0_7     GPIO->B[0][7]
#define PT0_8     GPIO->B[0][8]
#define PT0_9     GPIO->B[0][9]
#define PT0_10    GPIO->B[0][10]
#define PT0_11    GPIO->B[0][11]
#define PT0_12    GPIO->B[0][12]
#define PT0_13    GPIO->B[0][13]
#define PT0_14    GPIO->B[0][14]
#define PT0_15    GPIO->B[0][15]
#define PT0_16    GPIO->B[0][16]
#define PT0_17    GPIO->B[0][17]
#define PT0_18    GPIO->B[0][18]
#define PT0_19    GPIO->B[0][19]
#define PT0_20    GPIO->B[0][20]
#define PT0_21    GPIO->B[0][21]
#define PT0_22    GPIO->B[0][22]
#define PT0_23    GPIO->B[0][23]
#define PT0_24    GPIO->B[0][24]
#define PT0_25    GPIO->B[0][25]
#define PT0_26    GPIO->B[0][26]
#define PT0_27    GPIO->B[0][27]
#define PT0_28    GPIO->B[0][28]
#define PT0_29    GPIO->B[0][29]
#define PT0_30    GPIO->B[0][30]
#define PT0_31    GPIO->B[0][31]

//����PT1_�Ķ˿�  base->B[port][pin] = output;
#define PT1_0     GPIO->B[1][0]
#define PT1_1     GPIO->B[1][1]
#define PT1_2     GPIO->B[1][2]
#define PT1_3     GPIO->B[1][3]
#define PT1_4     GPIO->B[1][4]
#define PT1_5     GPIO->B[1][5]
#define PT1_6     GPIO->B[1][6]
#define PT1_7     GPIO->B[1][7]
#define PT1_8     GPIO->B[1][8]
#define PT1_9     GPIO->B[1][9]
#define PT1_10    GPIO->B[1][10]
#define PT1_11    GPIO->B[1][11]
#define PT1_12    GPIO->B[1][12]
#define PT1_13    GPIO->B[1][13]
#define PT1_14    GPIO->B[1][14]
#define PT1_15    GPIO->B[1][15]
#define PT1_16    GPIO->B[1][16]
#define PT1_17    GPIO->B[1][17]
#define PT1_18    GPIO->B[1][18]
#define PT1_19    GPIO->B[1][19]
#define PT1_20    GPIO->B[1][20]
#define PT1_21    GPIO->B[1][21]
#define PT1_22    GPIO->B[1][22]
#define PT1_23    GPIO->B[1][23]
#define PT1_24    GPIO->B[1][24]
#define PT1_25    GPIO->B[1][25]
#define PT1_26    GPIO->B[1][26]
#define PT1_27    GPIO->B[1][27]
#define PT1_28    GPIO->B[1][28]
#define PT1_29    GPIO->B[1][29]
#define PT1_30    GPIO->B[1][30]
#define PT1_31    GPIO->B[1][31]

//����PT2_�Ķ˿�  base->B[port][pin] = output;
#define PT2_0     GPIO->B[2][0]
#define PT2_1     GPIO->B[2][1]
#define PT2_2     GPIO->B[2][2]
#define PT2_3     GPIO->B[2][3]
#define PT2_4     GPIO->B[2][4]
#define PT2_5     GPIO->B[2][5]
#define PT2_6     GPIO->B[2][6]
#define PT2_7     GPIO->B[2][7]
#define PT2_8     GPIO->B[2][8]
#define PT2_9     GPIO->B[2][9]
#define PT2_10    GPIO->B[2][10]
#define PT2_11    GPIO->B[2][11]
#define PT2_12    GPIO->B[2][12]
#define PT2_13    GPIO->B[2][13]
#define PT2_14    GPIO->B[2][14]
#define PT2_15    GPIO->B[2][15]
#define PT2_16    GPIO->B[2][16]
#define PT2_17    GPIO->B[2][17]
#define PT2_18    GPIO->B[2][18]
#define PT2_19    GPIO->B[2][19]
#define PT2_20    GPIO->B[2][20]
#define PT2_21    GPIO->B[2][21]
#define PT2_22    GPIO->B[2][22]
#define PT2_23    GPIO->B[2][23]
#define PT2_24    GPIO->B[2][24]
#define PT2_25    GPIO->B[2][25]
#define PT2_26    GPIO->B[2][26]
#define PT2_27    GPIO->B[2][27]
#define PT2_28    GPIO->B[2][28]
#define PT2_29    GPIO->B[2][29]
#define PT2_30    GPIO->B[2][30]
#define PT2_31    GPIO->B[2][31]

//����PT3_�Ķ˿�  base->B[port][pin] = output;
#define PT3_0     GPIO->B[3][0]
#define PT3_1     GPIO->B[3][1]
#define PT3_2     GPIO->B[3][2]
#define PT3_3     GPIO->B[3][3]
#define PT3_4     GPIO->B[3][4]
#define PT3_5     GPIO->B[3][5]
#define PT3_6     GPIO->B[3][6]
#define PT3_7     GPIO->B[3][7]
#define PT3_8     GPIO->B[3][8]
#define PT3_9     GPIO->B[3][9]
#define PT3_10    GPIO->B[3][10]
#define PT3_11    GPIO->B[3][11]
#define PT3_12    GPIO->B[3][12]
#define PT3_13    GPIO->B[3][13]
#define PT3_14    GPIO->B[3][14]
#define PT3_15    GPIO->B[3][15]
#define PT3_16    GPIO->B[3][16]
#define PT3_17    GPIO->B[3][17]
#define PT3_18    GPIO->B[3][18]
#define PT3_19    GPIO->B[3][19]
#define PT3_20    GPIO->B[3][20]
#define PT3_21    GPIO->B[3][21]
#define PT3_22    GPIO->B[3][22]
#define PT3_23    GPIO->B[3][23]
#define PT3_24    GPIO->B[3][24]
#define PT3_25    GPIO->B[3][25]
#define PT3_26    GPIO->B[3][26]
#define PT3_27    GPIO->B[3][27]
#define PT3_28    GPIO->B[3][28]
#define PT3_29    GPIO->B[3][29]
#define PT3_30    GPIO->B[3][30]
#define PT3_31    GPIO->B[3][31]

//����PT4_�Ķ˿�  base->B[port][pin] = output;
#define PT4_0     GPIO->B[4][0]
#define PT4_1     GPIO->B[4][1]
#define PT4_2     GPIO->B[4][2]
#define PT4_3     GPIO->B[4][3]
#define PT4_4     GPIO->B[4][4]
#define PT4_5     GPIO->B[4][5]
#define PT4_6     GPIO->B[4][6]
#define PT4_7     GPIO->B[4][7]
#define PT4_8     GPIO->B[4][8]
#define PT4_9     GPIO->B[4][9]
#define PT4_10    GPIO->B[4][10]
#define PT4_11    GPIO->B[4][11]
#define PT4_12    GPIO->B[4][12]
#define PT4_13    GPIO->B[4][13]
#define PT4_14    GPIO->B[4][14]
#define PT4_15    GPIO->B[4][15]
#define PT4_16    GPIO->B[4][16]
#define PT4_17    GPIO->B[4][17]
#define PT4_18    GPIO->B[4][18]
#define PT4_19    GPIO->B[4][19]
#define PT4_20    GPIO->B[4][20]
#define PT4_21    GPIO->B[4][21]
#define PT4_22    GPIO->B[4][22]
#define PT4_23    GPIO->B[4][23]
#define PT4_24    GPIO->B[4][24]
#define PT4_25    GPIO->B[4][25]
#define PT4_26    GPIO->B[4][26]
#define PT4_27    GPIO->B[4][27]
#define PT4_28    GPIO->B[4][28]
#define PT4_29    GPIO->B[4][29]
#define PT4_30    GPIO->B[4][30]
#define PT4_31    GPIO->B[4][31]

//����PT0_��������뷽��  
#define PT0_0_DIR     GPIO->DIRs[0].BIT0
#define PT0_1_DIR     GPIO->DIRs[0].BIT1
#define PT0_2_DIR     GPIO->DIRs[0].BIT2
#define PT0_3_DIR     GPIO->DIRs[0].BIT3
#define PT0_4_DIR     GPIO->DIRs[0].BIT4
#define PT0_5_DIR     GPIO->DIRs[0].BIT5
#define PT0_6_DIR     GPIO->DIRs[0].BIT6
#define PT0_7_DIR     GPIO->DIRs[0].BIT7
#define PT0_8_DIR     GPIO->DIRs[0].BIT8
#define PT0_9_DIR     GPIO->DIRs[0].BIT9
#define PT0_10_DIR    GPIO->DIRs[0].BIT10
#define PT0_11_DIR    GPIO->DIRs[0].BIT11
#define PT0_12_DIR    GPIO->DIRs[0].BIT12
#define PT0_13_DIR    GPIO->DIRs[0].BIT13
#define PT0_14_DIR    GPIO->DIRs[0].BIT14
#define PT0_15_DIR    GPIO->DIRs[0].BIT15
#define PT0_16_DIR    GPIO->DIRs[0].BIT16
#define PT0_17_DIR    GPIO->DIRs[0].BIT17
#define PT0_18_DIR    GPIO->DIRs[0].BIT18
#define PT0_19_DIR    GPIO->DIRs[0].BIT19
#define PT0_20_DIR    GPIO->DIRs[0].BIT20
#define PT0_21_DIR    GPIO->DIRs[0].BIT21
#define PT0_22_DIR    GPIO->DIRs[0].BIT22
#define PT0_23_DIR    GPIO->DIRs[0].BIT23
#define PT0_24_DIR    GPIO->DIRs[0].BIT24
#define PT0_25_DIR    GPIO->DIRs[0].BIT25
#define PT0_26_DIR    GPIO->DIRs[0].BIT26
#define PT0_27_DIR    GPIO->DIRs[0].BIT27
#define PT0_28_DIR    GPIO->DIRs[0].BIT28
#define PT0_29_DIR    GPIO->DIRs[0].BIT29
#define PT0_30_DIR    GPIO->DIRs[0].BIT30
#define PT0_31_DIR    GPIO->DIRs[0].BIT31

//����PT1_��������뷽��  
#define PT1_0_DIR     GPIO->DIRs[1].BIT0
#define PT1_1_DIR     GPIO->DIRs[1].BIT1
#define PT1_2_DIR     GPIO->DIRs[1].BIT2
#define PT1_3_DIR     GPIO->DIRs[1].BIT3
#define PT1_4_DIR     GPIO->DIRs[1].BIT4
#define PT1_5_DIR     GPIO->DIRs[1].BIT5
#define PT1_6_DIR     GPIO->DIRs[1].BIT6
#define PT1_7_DIR     GPIO->DIRs[1].BIT7
#define PT1_8_DIR     GPIO->DIRs[1].BIT8
#define PT1_9_DIR     GPIO->DIRs[1].BIT9
#define PT1_10_DIR    GPIO->DIRs[1].BIT10
#define PT1_11_DIR    GPIO->DIRs[1].BIT11
#define PT1_12_DIR    GPIO->DIRs[1].BIT12
#define PT1_13_DIR    GPIO->DIRs[1].BIT13
#define PT1_14_DIR    GPIO->DIRs[1].BIT14
#define PT1_15_DIR    GPIO->DIRs[1].BIT15
#define PT1_16_DIR    GPIO->DIRs[1].BIT16
#define PT1_17_DIR    GPIO->DIRs[1].BIT17
#define PT1_18_DIR    GPIO->DIRs[1].BIT18
#define PT1_19_DIR    GPIO->DIRs[1].BIT19
#define PT1_20_DIR    GPIO->DIRs[1].BIT20
#define PT1_21_DIR    GPIO->DIRs[1].BIT21
#define PT1_22_DIR    GPIO->DIRs[1].BIT22
#define PT1_23_DIR    GPIO->DIRs[1].BIT23
#define PT1_24_DIR    GPIO->DIRs[1].BIT24
#define PT1_25_DIR    GPIO->DIRs[1].BIT25
#define PT1_26_DIR    GPIO->DIRs[1].BIT26
#define PT1_27_DIR    GPIO->DIRs[1].BIT27
#define PT1_28_DIR    GPIO->DIRs[1].BIT28
#define PT1_29_DIR    GPIO->DIRs[1].BIT29
#define PT1_30_DIR    GPIO->DIRs[1].BIT30
#define PT1_31_DIR    GPIO->DIRs[1].BIT31

//����PT2_��������뷽��  
#define PT2_0_DIR     GPIO->DIRs[2].BIT0
#define PT2_1_DIR     GPIO->DIRs[2].BIT1
#define PT2_2_DIR     GPIO->DIRs[2].BIT2
#define PT2_3_DIR     GPIO->DIRs[2].BIT3
#define PT2_4_DIR     GPIO->DIRs[2].BIT4
#define PT2_5_DIR     GPIO->DIRs[2].BIT5
#define PT2_6_DIR     GPIO->DIRs[2].BIT6
#define PT2_7_DIR     GPIO->DIRs[2].BIT7
#define PT2_8_DIR     GPIO->DIRs[2].BIT8
#define PT2_9_DIR     GPIO->DIRs[2].BIT9
#define PT2_10_DIR    GPIO->DIRs[2].BIT10
#define PT2_11_DIR    GPIO->DIRs[2].BIT11
#define PT2_12_DIR    GPIO->DIRs[2].BIT12
#define PT2_13_DIR    GPIO->DIRs[2].BIT13
#define PT2_14_DIR    GPIO->DIRs[2].BIT14
#define PT2_15_DIR    GPIO->DIRs[2].BIT15
#define PT2_16_DIR    GPIO->DIRs[2].BIT16
#define PT2_17_DIR    GPIO->DIRs[2].BIT17
#define PT2_18_DIR    GPIO->DIRs[2].BIT18
#define PT2_19_DIR    GPIO->DIRs[2].BIT19
#define PT2_20_DIR    GPIO->DIRs[2].BIT20
#define PT2_21_DIR    GPIO->DIRs[2].BIT21
#define PT2_22_DIR    GPIO->DIRs[2].BIT22
#define PT2_23_DIR    GPIO->DIRs[2].BIT23
#define PT2_24_DIR    GPIO->DIRs[2].BIT24
#define PT2_25_DIR    GPIO->DIRs[2].BIT25
#define PT2_26_DIR    GPIO->DIRs[2].BIT26
#define PT2_27_DIR    GPIO->DIRs[2].BIT27
#define PT2_28_DIR    GPIO->DIRs[2].BIT28
#define PT2_29_DIR    GPIO->DIRs[2].BIT29
#define PT2_30_DIR    GPIO->DIRs[2].BIT30
#define PT2_31_DIR    GPIO->DIRs[2].BIT31

//����PT3��������뷽��  
#define PT3_0_DIR     GPIO->DIRs[3].BIT0
#define PT3_1_DIR     GPIO->DIRs[3].BIT1
#define PT3_2_DIR     GPIO->DIRs[3].BIT2
#define PT3_3_DIR     GPIO->DIRs[3].BIT3
#define PT3_4_DIR     GPIO->DIRs[3].BIT4
#define PT3_5_DIR     GPIO->DIRs[3].BIT5
#define PT3_6_DIR     GPIO->DIRs[3].BIT6
#define PT3_7_DIR     GPIO->DIRs[3].BIT7
#define PT3_8_DIR     GPIO->DIRs[3].BIT8
#define PT3_9_DIR     GPIO->DIRs[3].BIT9
#define PT3_10_DIR    GPIO->DIRs[3].BIT10
#define PT3_11_DIR    GPIO->DIRs[3].BIT11
#define PT3_12_DIR    GPIO->DIRs[3].BIT12
#define PT3_13_DIR    GPIO->DIRs[3].BIT13
#define PT3_14_DIR    GPIO->DIRs[3].BIT14
#define PT3_15_DIR    GPIO->DIRs[3].BIT15
#define PT3_16_DIR    GPIO->DIRs[3].BIT16
#define PT3_17_DIR    GPIO->DIRs[3].BIT17
#define PT3_18_DIR    GPIO->DIRs[3].BIT18
#define PT3_19_DIR    GPIO->DIRs[3].BIT19
#define PT3_20_DIR    GPIO->DIRs[3].BIT20
#define PT3_21_DIR    GPIO->DIRs[3].BIT21
#define PT3_22_DIR    GPIO->DIRs[3].BIT22
#define PT3_23_DIR    GPIO->DIRs[3].BIT23
#define PT3_24_DIR    GPIO->DIRs[3].BIT24
#define PT3_25_DIR    GPIO->DIRs[3].BIT25
#define PT3_26_DIR    GPIO->DIRs[3].BIT26
#define PT3_27_DIR    GPIO->DIRs[3].BIT27
#define PT3_28_DIR    GPIO->DIRs[3].BIT28
#define PT3_29_DIR    GPIO->DIRs[3].BIT29
#define PT3_30_DIR    GPIO->DIRs[3].BIT30
#define PT3_31_DIR    GPIO->DIRs[3].BIT31

//����PT4��������뷽��  
#define PT4_0_DIR     GPIO->DIRs[4].BIT0
#define PT4_1_DIR     GPIO->DIRs[4].BIT1
#define PT4_2_DIR     GPIO->DIRs[4].BIT2
#define PT4_3_DIR     GPIO->DIRs[4].BIT3
#define PT4_4_DIR     GPIO->DIRs[4].BIT4
#define PT4_5_DIR     GPIO->DIRs[4].BIT5
#define PT4_6_DIR     GPIO->DIRs[4].BIT6
#define PT4_7_DIR     GPIO->DIRs[4].BIT7
#define PT4_8_DIR     GPIO->DIRs[4].BIT8
#define PT4_9_DIR     GPIO->DIRs[4].BIT9
#define PT4_10_DIR    GPIO->DIRs[4].BIT10
#define PT4_11_DIR    GPIO->DIRs[4].BIT11
#define PT4_12_DIR    GPIO->DIRs[4].BIT12
#define PT4_13_DIR    GPIO->DIRs[4].BIT13
#define PT4_14_DIR    GPIO->DIRs[4].BIT14
#define PT4_15_DIR    GPIO->DIRs[4].BIT15
#define PT4_16_DIR    GPIO->DIRs[4].BIT16
#define PT4_17_DIR    GPIO->DIRs[4].BIT17
#define PT4_18_DIR    GPIO->DIRs[4].BIT18
#define PT4_19_DIR    GPIO->DIRs[4].BIT19
#define PT4_20_DIR    GPIO->DIRs[4].BIT20
#define PT4_21_DIR    GPIO->DIRs[4].BIT21
#define PT4_22_DIR    GPIO->DIRs[4].BIT22
#define PT4_23_DIR    GPIO->DIRs[4].BIT23
#define PT4_24_DIR    GPIO->DIRs[4].BIT24
#define PT4_25_DIR    GPIO->DIRs[4].BIT25
#define PT4_26_DIR    GPIO->DIRs[4].BIT26
#define PT4_27_DIR    GPIO->DIRs[4].BIT27
#define PT4_28_DIR    GPIO->DIRs[4].BIT28
#define PT4_29_DIR    GPIO->DIRs[4].BIT29
#define PT4_30_DIR    GPIO->DIRs[4].BIT30
#define PT4_31_DIR    GPIO->DIRs[4].BIT31

//����PT0_������˿�   base->B[port][pin] = output;
#define PT0_0_IN     (GPIO->PIN[0])& (1 << 0)
#define PT0_1_IN     (GPIO->PIN[0])& (1 << 1)
#define PT0_2_IN     (GPIO->PIN[0])& (1 << 2)
#define PT0_3_IN     (GPIO->PIN[0])& (1 << 3)
#define PT0_4_IN     (GPIO->PIN[0])& (1 << 4)
#define PT0_5_IN     (GPIO->PIN[0])& (1 << 5)
#define PT0_6_IN     (GPIO->PIN[0])& (1 << 6)
#define PT0_7_IN     (GPIO->PIN[0])& (1 << 7)
#define PT0_8_IN     (GPIO->PIN[0])& (1 << 8)
#define PT0_9_IN     (GPIO->PIN[0])& (1 << 9)
#define PT0_10_IN    (GPIO->PIN[0])& (1 << 10)
#define PT0_11_IN    (GPIO->PIN[0])& (1 << 11)
#define PT0_12_IN    (GPIO->PIN[0])& (1 << 12)
#define PT0_13_IN    (GPIO->PIN[0])& (1 << 13)
#define PT0_14_IN    (GPIO->PIN[0])& (1 << 14)
#define PT0_15_IN    (GPIO->PIN[0])& (1 << 15)
#define PT0_16_IN    (GPIO->PIN[0])& (1 << 16)
#define PT0_17_IN    (GPIO->PIN[0])& (1 << 17)
#define PT0_18_IN    (GPIO->PIN[0])& (1 << 18)
#define PT0_19_IN    (GPIO->PIN[0])& (1 << 19)
#define PT0_20_IN    (GPIO->PIN[0])& (1 << 20)
#define PT0_21_IN    (GPIO->PIN[0])& (1 << 21)
#define PT0_22_IN    (GPIO->PIN[0])& (1 << 22)
#define PT0_23_IN    (GPIO->PIN[0])& (1 << 23)
#define PT0_24_IN    (GPIO->PIN[0])& (1 << 24)
#define PT0_25_IN    (GPIO->PIN[0])& (1 << 25)
#define PT0_26_IN    (GPIO->PIN[0])& (1 << 26)
#define PT0_27_IN    (GPIO->PIN[0])& (1 << 27)
#define PT0_28_IN    (GPIO->PIN[0])& (1 << 28)
#define PT0_29_IN    (GPIO->PIN[0])& (1 << 29)
#define PT0_30_IN    (GPIO->PIN[0])& (1 << 30)
#define PT0_31_IN    (GPIO->PIN[0])& (1 << 31)

//����PT1_������˿�  
#define PT1_0_IN     (GPIO->PIN[1])& (1 << 0)
#define PT1_1_IN     (GPIO->PIN[1])& (1 << 1)
#define PT1_2_IN     (GPIO->PIN[1])& (1 << 2)
#define PT1_3_IN     (GPIO->PIN[1])& (1 << 3)
#define PT1_4_IN     (GPIO->PIN[1])& (1 << 4)
#define PT1_5_IN     (GPIO->PIN[1])& (1 << 5)
#define PT1_6_IN     (GPIO->PIN[1])& (1 << 6)
#define PT1_7_IN     (GPIO->PIN[1])& (1 << 7)
#define PT1_8_IN     (GPIO->PIN[1])& (1 << 8)
#define PT1_9_IN     (GPIO->PIN[1])& (1 << 9)
#define PT1_10_IN    (GPIO->PIN[1])& (1 << 10)
#define PT1_11_IN    (GPIO->PIN[1])& (1 << 11)
#define PT1_12_IN    (GPIO->PIN[1])& (1 << 12)
#define PT1_13_IN    (GPIO->PIN[1])& (1 << 13)
#define PT1_14_IN    (GPIO->PIN[1])& (1 << 14)
#define PT1_15_IN    (GPIO->PIN[1])& (1 << 15)
#define PT1_16_IN    (GPIO->PIN[1])& (1 << 16)
#define PT1_17_IN    (GPIO->PIN[1])& (1 << 17)
#define PT1_18_IN    (GPIO->PIN[1])& (1 << 18)
#define PT1_19_IN    (GPIO->PIN[1])& (1 << 19)
#define PT1_20_IN    (GPIO->PIN[1])& (1 << 20)
#define PT1_21_IN    (GPIO->PIN[1])& (1 << 21)
#define PT1_22_IN    (GPIO->PIN[1])& (1 << 22)
#define PT1_23_IN    (GPIO->PIN[1])& (1 << 23)
#define PT1_24_IN    (GPIO->PIN[1])& (1 << 24)
#define PT1_25_IN    (GPIO->PIN[1])& (1 << 25)
#define PT1_26_IN    (GPIO->PIN[1])& (1 << 26)
#define PT1_27_IN    (GPIO->PIN[1])& (1 << 27)
#define PT1_28_IN    (GPIO->PIN[1])& (1 << 28)
#define PT1_29_IN    (GPIO->PIN[1])& (1 << 29)
#define PT1_30_IN    (GPIO->PIN[1])& (1 << 30)
#define PT1_31_IN    (GPIO->PIN[1])& (1 << 31)

//����PT2_������˿�  
#define PT2_0_IN     (GPIO->PIN[2])& (1 << 0)
#define PT2_1_IN     (GPIO->PIN[2])& (1 << 1)
#define PT2_2_IN     (GPIO->PIN[2])& (1 << 2)
#define PT2_3_IN     (GPIO->PIN[2])& (1 << 3)
#define PT2_4_IN     (GPIO->PIN[2])& (1 << 4)
#define PT2_5_IN     (GPIO->PIN[2])& (1 << 5)
#define PT2_6_IN     (GPIO->PIN[2])& (1 << 6)
#define PT2_7_IN     (GPIO->PIN[2])& (1 << 7)
#define PT2_8_IN     (GPIO->PIN[2])& (1 << 8)
#define PT2_9_IN     (GPIO->PIN[2])& (1 << 9)
#define PT2_10_IN    (GPIO->PIN[2])& (1 << 10)
#define PT2_11_IN    (GPIO->PIN[2])& (1 << 11)
#define PT2_12_IN    (GPIO->PIN[2])& (1 << 12)
#define PT2_13_IN    (GPIO->PIN[2])& (1 << 13)
#define PT2_14_IN    (GPIO->PIN[2])& (1 << 14)
#define PT2_15_IN    (GPIO->PIN[2])& (1 << 15)
#define PT2_16_IN    (GPIO->PIN[2])& (1 << 16)
#define PT2_17_IN    (GPIO->PIN[2])& (1 << 17)
#define PT2_18_IN    (GPIO->PIN[2])& (1 << 18)
#define PT2_19_IN    (GPIO->PIN[2])& (1 << 19)
#define PT2_20_IN    (GPIO->PIN[2])& (1 << 20)
#define PT2_21_IN    (GPIO->PIN[2])& (1 << 21)
#define PT2_22_IN    (GPIO->PIN[2])& (1 << 22)
#define PT2_23_IN    (GPIO->PIN[2])& (1 << 23)
#define PT2_24_IN    (GPIO->PIN[2])& (1 << 24)
#define PT2_25_IN    (GPIO->PIN[2])& (1 << 25)
#define PT2_26_IN    (GPIO->PIN[2])& (1 << 26)
#define PT2_27_IN    (GPIO->PIN[2])& (1 << 27)
#define PT2_28_IN    (GPIO->PIN[2])& (1 << 28)
#define PT2_29_IN    (GPIO->PIN[2])& (1 << 29)
#define PT2_30_IN    (GPIO->PIN[2])& (1 << 30)
#define PT2_31_IN    (GPIO->PIN[2])& (1 << 31)

//����PT3_������˿�  
#define PT3_0_IN     (GPIO->PIN[3])& (1 << 0)
#define PT3_1_IN     (GPIO->PIN[3])& (1 << 1)
#define PT3_2_IN     (GPIO->PIN[3])& (1 << 2)
#define PT3_3_IN     (GPIO->PIN[3])& (1 << 3)
#define PT3_4_IN     (GPIO->PIN[3])& (1 << 4)
#define PT3_5_IN     (GPIO->PIN[3])& (1 << 5)
#define PT3_6_IN     (GPIO->PIN[3])& (1 << 6)
#define PT3_7_IN     (GPIO->PIN[3])& (1 << 7)
#define PT3_8_IN     (GPIO->PIN[3])& (1 << 8)
#define PT3_9_IN     (GPIO->PIN[3])& (1 << 9)
#define PT3_10_IN    (GPIO->PIN[3])& (1 << 10)
#define PT3_11_IN    (GPIO->PIN[3])& (1 << 11)
#define PT3_12_IN    (GPIO->PIN[3])& (1 << 12)
#define PT3_13_IN    (GPIO->PIN[3])& (1 << 13)
#define PT3_14_IN    (GPIO->PIN[3])& (1 << 14)
#define PT3_15_IN    (GPIO->PIN[3])& (1 << 15)
#define PT3_16_IN    (GPIO->PIN[3])& (1 << 16)
#define PT3_17_IN    (GPIO->PIN[3])& (1 << 17)
#define PT3_18_IN    (GPIO->PIN[3])& (1 << 18)
#define PT3_19_IN    (GPIO->PIN[3])& (1 << 19)
#define PT3_20_IN    (GPIO->PIN[3])& (1 << 20)
#define PT3_21_IN    (GPIO->PIN[3])& (1 << 21)
#define PT3_22_IN    (GPIO->PIN[3])& (1 << 22)
#define PT3_23_IN    (GPIO->PIN[3])& (1 << 23)
#define PT3_24_IN    (GPIO->PIN[3])& (1 << 24)
#define PT3_25_IN    (GPIO->PIN[3])& (1 << 25)
#define PT3_26_IN    (GPIO->PIN[3])& (1 << 26)
#define PT3_27_IN    (GPIO->PIN[3])& (1 << 27)
#define PT3_28_IN    (GPIO->PIN[3])& (1 << 28)
#define PT3_29_IN    (GPIO->PIN[3])& (1 << 29)
#define PT3_30_IN    (GPIO->PIN[3])& (1 << 30)
#define PT3_31_IN    (GPIO->PIN[3])& (1 << 31)

//����PT4_������˿�  
#define PT4_0_IN     (GPIO->PIN[4])& (1 << 0)
#define PT4_1_IN     (GPIO->PIN[4])& (1 << 1)
#define PT4_2_IN     (GPIO->PIN[4])& (1 << 2)
#define PT4_3_IN     (GPIO->PIN[4])& (1 << 3)
#define PT4_4_IN     (GPIO->PIN[4])& (1 << 4)
#define PT4_5_IN     (GPIO->PIN[4])& (1 << 5)
#define PT4_6_IN     (GPIO->PIN[4])& (1 << 6)
#define PT4_7_IN     (GPIO->PIN[4])& (1 << 7)
#define PT4_8_IN     (GPIO->PIN[4])& (1 << 8)
#define PT4_9_IN     (GPIO->PIN[4])& (1 << 9)
#define PT4_10_IN    (GPIO->PIN[4])& (1 << 10)
#define PT4_11_IN    (GPIO->PIN[4])& (1 << 11)
#define PT4_12_IN    (GPIO->PIN[4])& (1 << 12)
#define PT4_13_IN    (GPIO->PIN[4])& (1 << 13)
#define PT4_14_IN    (GPIO->PIN[4])& (1 << 14)
#define PT4_15_IN    (GPIO->PIN[4])& (1 << 15)
#define PT4_16_IN    (GPIO->PIN[4])& (1 << 16)
#define PT4_17_IN    (GPIO->PIN[4])& (1 << 17)
#define PT4_18_IN    (GPIO->PIN[4])& (1 << 18)
#define PT4_19_IN    (GPIO->PIN[4])& (1 << 19)
#define PT4_20_IN    (GPIO->PIN[4])& (1 << 20)
#define PT4_21_IN    (GPIO->PIN[4])& (1 << 21)
#define PT4_22_IN    (GPIO->PIN[4])& (1 << 22)
#define PT4_23_IN    (GPIO->PIN[4])& (1 << 23)
#define PT4_24_IN    (GPIO->PIN[4])& (1 << 24)
#define PT4_25_IN    (GPIO->PIN[4])& (1 << 25)
#define PT4_26_IN    (GPIO->PIN[4])& (1 << 26)
#define PT4_27_IN    (GPIO->PIN[4])& (1 << 27)
#define PT4_28_IN    (GPIO->PIN[4])& (1 << 28)
#define PT4_29_IN    (GPIO->PIN[4])& (1 << 29)
#define PT4_30_IN    (GPIO->PIN[4])& (1 << 30)
#define PT4_31_IN    (GPIO->PIN[4])& (1 << 31)


//����PT0_��8λ�˿�  
#define PT0__BYTE0   GPIO->PINs[0].Byte0
#define PT0__BYTE1   GPIO->PINs[0].Byte1
#define PT0__BYTE2   GPIO->PINs[0].Byte2
#define PT0__BYTE3   GPIO->PINs[0].Byte3

#define PT1__BYTE0   GPIO->PINs[1].Byte0
#define PT1__BYTE1   GPIO->PINs[1].Byte1
#define PT1__BYTE2   GPIO->PINs[1].Byte2
#define PT1__BYTE3   GPIO->PINs[1].Byte3

#define PT2__BYTE0   GPIO->PINs[2].Byte0
#define PT2__BYTE1   GPIO->PINs[2].Byte1
#define PT2__BYTE2   GPIO->PINs[2].Byte2
#define PT2__BYTE3   GPIO->PINs[2].Byte3

#define PT3__BYTE0   GPIO->PINs[3].Byte0
#define PT3__BYTE1   GPIO->PINs[3].Byte1
#define PT3__BYTE2   GPIO->PINs[3].Byte2
#define PT3__BYTE3   GPIO->PINs[3].Byte3

#define PT4__BYTE0   GPIO->PINs[4].Byte0
#define PT4__BYTE1   GPIO->PINs[4].Byte1
#define PT4__BYTE2   GPIO->PINs[4].Byte2
#define PT4__BYTE3   GPIO->PINs[4].Byte3

/*

//����PT0_��8λ�˿�  
#define PT0__BYTE0_OUT   PT0__BASE_PTR->PDORByte.Byte0
#define PT0__BYTE1_OUT   PT0__BASE_PTR->PDORByte.Byte1
#define PT0__BYTE2_OUT   PT0__BASE_PTR->PDORByte.Byte2
#define PT0__BYTE3_OUT   PT0__BASE_PTR->PDORByte.Byte3

//����PT1_��8λ�˿�  
#define PT1__BYTE0_OUT   PT1__BASE_PTR->PDORByte.Byte0
#define PT1__BYTE1_OUT   PT1__BASE_PTR->PDORByte.Byte1
#define PT1__BYTE2_OUT   PT1__BASE_PTR->PDORByte.Byte2
#define PT1__BYTE3_OUT   PT1__BASE_PTR->PDORByte.Byte3


//����PT2_��8λ�˿�  
#define PT2__BYTE0_OUT   PT2__BASE_PTR->PDORByte.Byte0
#define PT2__BYTE1_OUT   PT2__BASE_PTR->PDORByte.Byte1
#define PT2__BYTE2_OUT   PT2__BASE_PTR->PDORByte.Byte2
#define PT2__BYTE3_OUT   PT2__BASE_PTR->PDORByte.Byte3

//����PT3_��8λ�˿�  
#define PT3__BYTE0_OUT   PT3__BASE_PTR->PDORByte.Byte0
#define PT3__BYTE1_OUT   PT3__BASE_PTR->PDORByte.Byte1
#define PT3__BYTE2_OUT   PT3__BASE_PTR->PDORByte.Byte2
#define PT3__BYTE3_OUT   PT3__BASE_PTR->PDORByte.Byte3

//����PT4_��8λ�˿�  
#define PT4__BYTE0_OUT   PT4__BASE_PTR->PDORByte.Byte0
#define PT4__BYTE1_OUT   PT4__BASE_PTR->PDORByte.Byte1
#define PT4__BYTE2_OUT   PT4__BASE_PTR->PDORByte.Byte2
#define PT4__BYTE3_OUT   PT4__BASE_PTR->PDORByte.Byte3


//����PT0_��8λ������뷽��  
#define DDRA_BYTE0   PT0__BASE_PTR->DDRByte.Byte0
#define DDRA_BYTE1   PT0__BASE_PTR->DDRByte.Byte1
#define DDRA_BYTE2   PT0__BASE_PTR->DDRByte.Byte2
#define DDRA_BYTE3   PT0__BASE_PTR->DDRByte.Byte3

//����PT1_��8λ������뷽��  
#define DDRB_BYTE0   PT1__BASE_PTR->DDRByte.Byte0
#define DDRB_BYTE1   PT1__BASE_PTR->DDRByte.Byte1
#define DDRB_BYTE2   PT1__BASE_PTR->DDRByte.Byte2
#define DDRB_BYTE3   PT1__BASE_PTR->DDRByte.Byte3

//����PT2_��8λ������뷽��  
#define DDRC_BYTE0   PT2__BASE_PTR->DDRByte.Byte0
#define DDRC_BYTE1   PT2__BASE_PTR->DDRByte.Byte1
#define DDRC_BYTE2   PT2__BASE_PTR->DDRByte.Byte2
#define DDRC_BYTE3   PT2__BASE_PTR->DDRByte.Byte3

//����PT3_��8λ������뷽��  
#define DDRD_BYTE0   PT3__BASE_PTR->DDRByte.Byte0
#define DDRD_BYTE1   PT3__BASE_PTR->DDRByte.Byte1
#define DDRD_BYTE2   PT3__BASE_PTR->DDRByte.Byte2
#define DDRD_BYTE3   PT3__BASE_PTR->DDRByte.Byte3

//����PT4_��8λ������뷽��  
#define DDRE_BYTE0   PT4__BASE_PTR->DDRByte.Byte0
#define DDRE_BYTE1   PT4__BASE_PTR->DDRByte.Byte1
#define DDRE_BYTE2   PT4__BASE_PTR->DDRByte.Byte2
#define DDRE_BYTE3   PT4__BASE_PTR->DDRByte.Byte3


//����PT0_��8λ����˿�  
#define PT0__BYTE0_IN   PT0__BASE_PTR->PDIRByte.Byte0
#define PT0__BYTE1_IN   PT0__BASE_PTR->PDIRByte.Byte1
#define PT0__BYTE2_IN   PT0__BASE_PTR->PDIRByte.Byte2
#define PT0__BYTE3_IN   PT0__BASE_PTR->PDIRByte.Byte3

//����PT1_��8λ����˿�  
#define PT1__BYTE0_IN   PT1__BASE_PTR->PDIRByte.Byte0
#define PT1__BYTE1_IN   PT1__BASE_PTR->PDIRByte.Byte1
#define PT1__BYTE2_IN   PT1__BASE_PTR->PDIRByte.Byte2
#define PT1__BYTE3_IN   PT1__BASE_PTR->PDIRByte.Byte3

//����PT2_��8λ����˿�  
#define PT2__BYTE0_IN   PT2__BASE_PTR->PDIRByte.Byte0
#define PT2__BYTE1_IN   PT2__BASE_PTR->PDIRByte.Byte1
#define PT2__BYTE2_IN   PT2__BASE_PTR->PDIRByte.Byte2
#define PT2__BYTE3_IN   PT2__BASE_PTR->PDIRByte.Byte3


//����PT3_��8λ����˿�  
#define PT3__BYTE0_IN   PT3__BASE_PTR->PDIRByte.Byte0
#define PT3__BYTE1_IN   PT3__BASE_PTR->PDIRByte.Byte1
#define PT3__BYTE2_IN   PT3__BASE_PTR->PDIRByte.Byte2
#define PT3__BYTE3_IN   PT3__BASE_PTR->PDIRByte.Byte3

//����PT4_��8λ����˿�  
#define PT4__BYTE0_IN   PT4__BASE_PTR->PDIRByte.Byte0
#define PT4__BYTE1_IN   PT4__BASE_PTR->PDIRByte.Byte1
#define PT4__BYTE2_IN   PT4__BASE_PTR->PDIRByte.Byte2
#define PT4__BYTE3_IN   PT4__BASE_PTR->PDIRByte.Byte3


//����PT0_��16λ�˿�  
#define PT0__WORD0_OUT   PT0__BASE_PTR->PDORWord.Word0
#define PT0__WORD1_OUT   PT0__BASE_PTR->PDORWord.Word1

//����PT1_��16λ�˿�  
#define PT1__WORD0_OUT   PT1__BASE_PTR->PDORWord.Word0
#define PT1__WORD1_OUT   PT1__BASE_PTR->PDORWord.Word1

//����PT2_��16λ�˿�  
#define PT2__WORD0_OUT   PT2__BASE_PTR->PDORWord.Word0
#define PT2__WORD1_OUT   PT2__BASE_PTR->PDORWord.Word1


//����PT3_��16λ�˿�  
#define PT3__WORD0_OUT   PT3__BASE_PTR->PDORWord.Word0
#define PT3__WORD1_OUT   PT3__BASE_PTR->PDORWord.Word1


//����PT4_��16λ�˿�  
#define PT4__WORD0_OUT   PT4__BASE_PTR->PDORWord.Word0
#define PT4__WORD1_OUT   PT4__BASE_PTR->PDORWord.Word1


//����PT0_��16λ������뷽��  
#define DDRA_WORD0   PT0__BASE_PTR->DDRWord.Word0
#define DDRA_WORD1   PT0__BASE_PTR->DDRWord.Word1


//����PT1_��16λ������뷽��  
#define DDRB_WORD0   PT1__BASE_PTR->DDRWord.Word0
#define DDRB_WORD1   PT1__BASE_PTR->DDRWord.Word1


//����PT2_��16λ������뷽��  
#define DDRC_WORD0   PT2__BASE_PTR->DDRWord.Word0
#define DDRC_WORD1   PT2__BASE_PTR->DDRWord.Word1


//����PT3_��16λ������뷽��  
#define DDRD_WORD0   PT3__BASE_PTR->DDRWord.Word0
#define DDRD_WORD1   PT3__BASE_PTR->DDRWord.Word1


//����PT4_��16λ������뷽��  
#define DDRE_WORD0   PT4__BASE_PTR->DDRWord.Word0
#define DDRE_WORD1   PT4__BASE_PTR->DDRWord.Word1


//����PT0_��16λ����˿�  
#define PT0__WORD0_IN   PT0__BASE_PTR->PDIRWord.Word0
#define PT0__WORD1_IN   PT0__BASE_PTR->PDIRWord.Word1


//����PT1_��16λ����˿�  
#define PT1__WORD0_IN   PT1__BASE_PTR->PDIRWord.Word0
#define PT1__WORD1_IN   PT1__BASE_PTR->PDIRWord.Word1

//����PT2_��16λ����˿�  
#define PT2__WORD0_IN   PT2__BASE_PTR->PDIRWord.Word0
#define PT2__WORD1_IN   PT2__BASE_PTR->PDIRWord.Word1


//����PT3_��16λ����˿�  
#define PT3__WORD0_IN   PT3__BASE_PTR->PDIRWord.Word0
#define PT3__WORD1_IN   PT3__BASE_PTR->PDIRWord.Word1


//����PT4_��16λ����˿�  
#define PT4__WORD0_IN   PT4__BASE_PTR->PDIRWord.Word0
#define PT4__WORD1_IN   PT4__BASE_PTR->PDIRWord.Word1


*/




#endif
