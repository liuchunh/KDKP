/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
��ƽ    ̨�������������ܿƼ�LPC546XX���İ�
����    д��CHIUSIR
����    ע��10��ͨ�����ܲ���ͨ��
�������汾��V1.0
�������¡�2017��10��26��
�������Ϣ�ο����е�ַ��
����    վ��http://www.lqist.cn
���Ա����̡�http://shop36265907.taobao.com
���������䡿chiusir@163.com
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/

#include "include.h"

usart_config_t config;

//�������´���,֧��printf����,������Ҫѡ��use MicroLIB	  
//IAR����Ҫ��options -> C/C++compiler -> Preprocessor ���Ӻ궨�� _DLIB_FILE_DESCRIPTOR
#if 1
//#pragma import(__use_no_semihosting)             
//��׼����Ҫ��֧�ֺ���                 
struct __FILE 
{ 
	int handle; 
}; 

FILE __stdout;       
//����_sys_exit()�Ա���ʹ�ð�����ģʽ    
void _sys_exit(int x) 
{ 
	x = x; 
} 
//�ض���fputc����  ʹ�ô���0��Ϊprintf�Ĵ�ӡ��
int fputc(int ch, FILE *f)
{ 	
    while(!(kUSART_TxFifoNotFullFlag & USART_GetStatusFlags(USART0)));
    //��������
    USART_WriteByte(USART0, (uint8_t)ch);
	return ch;
}
#endif 


//-------------------------------------------------------------------------*
//������: UART_Init                                                        
//��  ��: ��ʼ������                                                      
//��  ��: uratn: ģ�����磺UART9
//        bdr  : ������
//��  ��: ��                                                              
//��  ��: UART_Init (UART4, 115200) �����յ������ݱ�����a������                                
//-------------------------------------------------------------------------*
void UART_Init(UARTn_e uratn,uint32_t bdr)
{    
    CLOCK_EnableClock(kCLOCK_Iocon);                           // Enables the clock for the IOCON block. 0 = Disable; 1 = Enable.: 0x01u 
    USART_GetDefaultConfig(&config);
    config.baudRate_Bps = bdr;
    config.enableTx = true;
    config.enableRx = true;
    
    switch(uratn)
    {
      case UART0:         
        if(UART0_RX==P0_29)
            IOCON_PinMuxSet(IOCON, 0, 29, PIOFun1_config); // PORT0 PIN29 (coords: B13) is configured as FC0_RXD_SDA_MOSI 
        else if(UART0_RX==P0_24)
            IOCON_PinMuxSet(IOCON, 0, 24, PIOFun1_config); 
        else if(UART0_RX==P1_5)
            IOCON_PinMuxSet(IOCON, 1, 5, PIOFun1_config);
        else if(UART0_RX==P2_0)
            IOCON_PinMuxSet(IOCON, 2, 0, PIOFun2_config);
        
        if(UART0_TX==P0_30)
            IOCON_PinMuxSet(IOCON, 0, 30, PIOFun1_config); // PORT0 PIN30 (coords: A2) is configured as FC0_TXD_SCL_MISO  
        else if(UART0_TX==P0_25)
            IOCON_PinMuxSet(IOCON, 0, 25, PIOFun1_config);
        else if(UART0_TX==P1_6)
            IOCON_PinMuxSet(IOCON, 1, 6, PIOFun1_config);
        else if(UART0_TX==P2_1)
            IOCON_PinMuxSet(IOCON, 2, 1, PIOFun2_config);
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM0);
        USART_EnableInterrupts(USART0, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART0, &config, CLOCK_GetFreq(kCLOCK_Flexcomm0)); 
        break;
      case UART1:
        if(UART1_RX==P1_10)
            IOCON_PinMuxSet(IOCON, 1, 10, PIOFun2_config); 
        else if(UART1_RX==P2_3)
            IOCON_PinMuxSet(IOCON, 2,  3, PIOFun3_config);
        else if(UART1_RX==P4_28)
            IOCON_PinMuxSet(IOCON, 4,  28, PIOFun4_config);
        if(UART1_TX==P1_11)
            IOCON_PinMuxSet(IOCON, 1, 11, PIOFun2_config);  
        else if(UART1_TX==P2_4)
            IOCON_PinMuxSet(IOCON, 2,  4, PIOFun3_config); 
        else if(UART1_TX==P0_10)
            IOCON_PinMuxSet(IOCON, 0,  10, PIOFun4_config);
        else if(UART1_TX==P4_29)
            IOCON_PinMuxSet(IOCON, 4,  29, PIOFun4_config);
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM1);
        USART_EnableInterrupts(USART1, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART1, &config, CLOCK_GetFreq(kCLOCK_Flexcomm1));
        break;
      case UART2:
        if(UART2_RX==P0_26)
            IOCON_PinMuxSet(IOCON, 0, 26, PIOFun1_config); 
        else if(UART2_RX==P1_24)
            IOCON_PinMuxSet(IOCON, 1, 24, PIOFun1_config); 
        else if(UART2_RX==P4_9)
            IOCON_PinMuxSet(IOCON, 4, 9, PIOFun2_config);
        else if(UART2_RX==P4_20)
            IOCON_PinMuxSet(IOCON, 4, 20, PIOFun3_config);
        if(UART2_TX==P0_27)
            IOCON_PinMuxSet(IOCON, 0, 27, PIOFun1_config); 
        else if(UART2_TX==P1_25)
            IOCON_PinMuxSet(IOCON, 1, 25, PIOFun1_config); 
        else if(UART2_TX==P4_10)
            IOCON_PinMuxSet(IOCON, 4, 10, PIOFun2_config); 
        else if(UART2_TX==P4_21)
            IOCON_PinMuxSet(IOCON, 4, 21, PIOFun3_config); 
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM2);
        USART_EnableInterrupts(USART2, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART2, &config, CLOCK_GetFreq(kCLOCK_Flexcomm2));
        break;
      case UART3:
        if(UART3_RX==P0_3)
            IOCON_PinMuxSet(IOCON, 0, 3, PIOFun1_config);
        else if(UART3_RX==P1_1)
            IOCON_PinMuxSet(IOCON, 1, 1, PIOFun1_config);
        else if(UART3_RX==P2_18)         
            IOCON_PinMuxSet(IOCON, 2, 18, PIOFun2_config);
        if(UART3_TX==P0_2)
            IOCON_PinMuxSet(IOCON, 0, 2, PIOFun1_config); 
        else if(UART3_TX==P0_12)
            IOCON_PinMuxSet(IOCON, 0, 12, PIOFun1_config); 
        else if(UART3_TX==P2_19)
            IOCON_PinMuxSet(IOCON, 2, 19, PIOFun2_config);         
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM3);
        USART_EnableInterrupts(USART3, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART3, &config, CLOCK_GetFreq(kCLOCK_Flexcomm3));
        break;
      case UART4:
        if(UART4_RX==P1_21)
            IOCON_PinMuxSet(IOCON, 1, 21, PIOFun5_config); 
        else if(UART4_RX==P0_5)
            IOCON_PinMuxSet(IOCON, 0, 5, PIOFun2_config);   
        else if(UART4_RX==P3_26)
            IOCON_PinMuxSet(IOCON, 3, 26, PIOFun3_config);
        else if(UART4_RX==P4_2)
            IOCON_PinMuxSet(IOCON, 4, 2, PIOFun2_config);
        else if(UART4_RX==P5_0)
            IOCON_PinMuxSet(IOCON, 5, 0, PIOFun4_config);        
        if(UART4_TX==P1_20)
            IOCON_PinMuxSet(IOCON, 1, 20, PIOFun5_config);   
        else if(UART4_TX==P0_16)
            IOCON_PinMuxSet(IOCON, 0, 16, PIOFun1_config);   
        else if(UART4_TX==P3_27)
            IOCON_PinMuxSet(IOCON, 3, 27, PIOFun3_config);
        else if(UART4_TX==P4_3)
            IOCON_PinMuxSet(IOCON, 4, 3, PIOFun2_config);
        else if(UART4_TX==P5_1)
            IOCON_PinMuxSet(IOCON, 5, 1, PIOFun4_config);
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM4);
        USART_EnableInterrupts(USART4, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART4, &config, CLOCK_GetFreq(kCLOCK_Flexcomm4));
        break;
      case UART5:
        if(UART5_RX==P0_8)
            IOCON_PinMuxSet(IOCON, 0, 8, PIOFun3_config);  
        else if(UART5_RX==P2_12)
            IOCON_PinMuxSet(IOCON, 2, 12, PIOFun5_config);
        else if(UART5_RX==P5_7)
            IOCON_PinMuxSet(IOCON, 5, 7, PIOFun3_config);
        if(UART5_TX==P0_9)
            IOCON_PinMuxSet(IOCON, 0, 9, PIOFun3_config);
        else if(UART5_TX==P2_13)
            IOCON_PinMuxSet(IOCON, 2, 13, PIOFun5_config);   
        else if(UART5_TX==P5_8)
            IOCON_PinMuxSet(IOCON, 5, 8, PIOFun3_config);
        
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM5);
        USART_EnableInterrupts(USART5, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART5, &config, CLOCK_GetFreq(kCLOCK_Flexcomm5));
        break;
      case UART6:
        if(UART6_RX==P0_11)
            IOCON_PinMuxSet(IOCON, 0, 11, PIOFun1_config);  
        else if(UART6_RX==P1_13)
            IOCON_PinMuxSet(IOCON, 1, 13, PIOFun2_config);  
        if(UART6_TX==P0_22)
            IOCON_PinMuxSet(IOCON, 0, 22, PIOFun1_config); 
        else if(UART6_TX==P1_16)
            IOCON_PinMuxSet(IOCON, 1, 16, PIOFun2_config); 
        
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM6);
        USART_EnableInterrupts(USART6, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART6, &config, CLOCK_GetFreq(kCLOCK_Flexcomm6));
        break;
      case UART7:
        if(UART7_RX==P1_29)
            IOCON_PinMuxSet(IOCON, 1, 29, PIOFun1_config);
        else if(UART7_RX==P0_20)
            IOCON_PinMuxSet(IOCON, 0, 20, PIOFun7_config);
        else if(UART7_RX==P2_19)
            IOCON_PinMuxSet(IOCON, 2, 19, PIOFun3_config); 
        
        if(UART7_TX==P1_30)
            IOCON_PinMuxSet(IOCON, 1, 30, PIOFun1_config);
        else if(UART7_TX==P0_19)         
            IOCON_PinMuxSet(IOCON, 0, 19, PIOFun7_config);
        else if(UART7_TX==P2_20)         
            IOCON_PinMuxSet(IOCON, 2, 20, PIOFun3_config);
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM7);
        USART_EnableInterrupts(USART7, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART7, &config, CLOCK_GetFreq(kCLOCK_Flexcomm7));
        break;
      case UART8:
        if(UART8_RX==P1_17)
            IOCON_PinMuxSet(IOCON, 1, 17, PIOFun2_config);
        else if(UART8_RX==P2_17)
            IOCON_PinMuxSet(IOCON, 2, 17, PIOFun5_config);
        else if(UART8_RX==P3_16)
            IOCON_PinMuxSet(IOCON, 3, 16, PIOFun1_config);
        
        if(UART8_TX==P1_18)
            IOCON_PinMuxSet(IOCON, 1, 18, PIOFun2_config);
        else if(UART8_TX==P2_18)         
            IOCON_PinMuxSet(IOCON, 2, 18, PIOFun2_config);
        else if(UART8_TX==P2_29)         
            IOCON_PinMuxSet(IOCON, 2, 29, PIOFun3_config);
        else if(UART8_TX==P3_17)
            IOCON_PinMuxSet(IOCON, 3, 17, PIOFun1_config);
        
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM8);
        USART_EnableInterrupts(USART8, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART8, &config, CLOCK_GetFreq(kCLOCK_Flexcomm8));
        break;
      case UART9:
        if(UART9_RX==P3_2)
            IOCON_PinMuxSet(IOCON, 3, 2, PIOFun2_config);
        else if(UART9_RX==P2_17)
            IOCON_PinMuxSet(IOCON, 2, 17, PIOFun5_config);
        else if(UART9_RX==P3_21)
            IOCON_PinMuxSet(IOCON, 3, 21, PIOFun1_config);
        else if(UART9_RX==P4_15)
            IOCON_PinMuxSet(IOCON, 4, 15, PIOFun3_config);
        if(UART9_TX==P3_3)
            IOCON_PinMuxSet(IOCON, 3, 3, PIOFun2_config);
        else if(UART9_TX==P2_19)         
            IOCON_PinMuxSet(IOCON, 2, 19, PIOFun2_config);
        else if(UART9_TX==P2_29)         
            IOCON_PinMuxSet(IOCON, 2, 29, PIOFun3_config);
        else if(UART9_TX==P3_22)         
            IOCON_PinMuxSet(IOCON, 3, 22, PIOFun1_config);
        else if(UART9_TX==P4_16)         
            IOCON_PinMuxSet(IOCON, 4, 16, PIOFun3_config);
        CLOCK_AttachClk(kFRO12M_to_FLEXCOMM9);
        USART_EnableInterrupts(USART9, kUSART_RxLevelInterruptEnable | kUSART_RxErrorInterruptEnable);
        USART_Init(USART9, &config, CLOCK_GetFreq(kCLOCK_Flexcomm9));
        break;
      default:
        break;
    }    
}

//-------------------------------------------------------------------------*
//������: UARTgetchar                                                        
//��  ��: ����һ���ֽ�                                                        
//��  ��: uratn:ģ�����磺USART9
//        ch: �����������ָ��
//��  ��: ��                                                              
//��  ��: UART_GetChar (USART4) �����յ������ݱ�����a������                                
//-------------------------------------------------------------------------*
char UART_GetChar (USART_Type * uratn)
{    
    /* �ȴ��������� */
    while(!(kUSART_RxFifoNotEmptyFlag & USART_GetStatusFlags(uratn)));
    
    /* ��ȡ���յ���8λ���� */
    return (USART_ReadByte(uratn));

}

//-------------------------------------------------------------------------*
//������: UARTputchar                                                        
//��  ��: ����һ���ֽ�                                                       
//��  ��: uratn:ģ�����磺USART9
//         ch: ���͵��ֽ�
//��  ��: ��                                                              
//��  ��: UART_PutChar (USART4, 0x66);                               
//-------------------------------------------------------------------------*
void UART_PutChar (USART_Type * uratn, char ch)
{
    //�ȴ����ͻ�������
    while(!(kUSART_TxFifoNotFullFlag & USART_GetStatusFlags(uratn)));
    
    //��������
    USART_WriteByte(uratn, (uint8_t)ch);
}



//-------------------------------------------------------------------------*
//������: UARTputstr                                                        
//��  ��: �����ַ���(�� NULL ֹͣ����)                                                       
//��  ��: uratn:ģ�����磺USART0 
//        str: ���͵ĵ�ַ��
//��  ��: ��                                                              
//��  ��: UART_PutStr (USART4, "123456789");ʵ�ʷ���9���ֽ�                              
//-------------------------------------------------------------------------*
void UART_PutStr(USART_Type * uratn, char *str)
{    
   while(*str)
    {
        UART_PutChar(uratn, *str++);
    }
    
}

//-------------------------------------------------------------------------*
//������: UART_PutBuff                                                        
//��  ��: ����ָ��len���ֽڳ������� ������ NULL Ҳ�ᷢ�ͣ�                                                       
//��  ��: base:ģ�����磺USART0 
//        buff: ���͵ĵ�ַ��
//        len : ����ָ������
//��  ��: ��                                                              
//��  ��: UART_PutBuff (UART4, "123456789",5);ʵ�ʷ���5���ֽڡ�1����2����3����4����5��                               
//-------------------------------------------------------------------------*
void UART_PutBuff(USART_Type *base, uint8_t *buff, uint32_t len)
{
    while(len--)
    {
        UART_PutChar(base, *buff);
        buff++;
    }
}
 
//-------------------------------------------------------------------------*
//������: Test_UART                                                       
//��  ��: ���Դ����շ�                                                       
//��  ��: ��
//��  ��: ��                                                              
//��  ��:                              
//-------------------------------------------------------------------------*
void Test_UART(void)
{
    LED_Init();
    
    UART_Init(UART0,115200);
    
    /* 
     * ���ȼ����� ��ռ���ȼ�1  �����ȼ�3   ԽС���ȼ�Խ��  ��ռ���ȼ��ߵĿɴ����ռ���ȼ��͵��ж�
     * �������ж�ͬʱ����ʱ�������ȼ��ߵ���ִ��
     */
    NVIC_SetPriority(FLEXCOMM0_IRQn,NVIC_EncodePriority(NVIC_GetPriorityGrouping(),1,3));
    
    /* ʹ���ж� */
    EnableIRQ(FLEXCOMM0_IRQn);
    
    UART_PutStr(USART0,"UART_PutStr: LongQiu UART0 \n");
    
    printf("printf: ���񴮿ڲ���\n");
   
    PRINTF("PRINTF: ���񴮿ڲ���\n");
    while (1)
    {       
      LED_Color_Reverse(red);     
     
      delayms(500);
    }
}


