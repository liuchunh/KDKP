
#ifndef _CLOCK_CONFIG_H_
#define _CLOCK_CONFIG_H_

#include "fsl_common.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define BOARD_XTAL0_CLK_HZ                         12000000U  /*!< Board xtal0 frequency in Hz */
#define BOARD_XTAL32K_CLK_HZ                          32768U  /*!< Board xtal32K frequency in Hz */
#define BOARD_BootClockRUN BOARD_BootClockFROHF48M

#define BOARD_BOOTCLOCKFRO12M_CORE_CLOCK   12000000U    /*!< Core clock frequency:12000000Hz */
void BOARD_BootClockFRO12M(void);

#define BOARD_BOOTCLOCKFROHF48M_CORE_CLOCK   48000000U    /*!< Core clock frequency:48000000Hz */
void BOARD_BootClockFROHF48M(void);

#define BOARD_BOOTCLOCKFROHF96M_CORE_CLOCK   96000000U    /*!< Core clock frequency:96000000Hz */
void BOARD_BootClockFROHF96M(void);

#define BOARD_BootClockPLL180M_CORE_CLOCK   180000000U    /*!< Core clock frequency:180000000Hz */
void BOARD_BootClockPLL180M(void);
void BOARD_BootClockPLL220M(void);
#endif /* _CLOCK_CONFIG_H_ */

