/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
��ƽ    ̨�������������ܿƼ�LPC546XX���İ�
����    д��CHIUSIR
����    ע��
�������汾��V1.0
�������¡�2017��10��22��
�������Ϣ�ο����е�ַ��
����    վ��http://www.lqist.cn
���Ա����̡�http://shop36265907.taobao.com
���������䡿chiusir@163.com
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/


#ifndef __ADC_H__
#define __ADC_H__ 
/*

*/
typedef enum
{
    ADC_ThresholdCompareFlagOnChn0 = 1U << 0U,  // Threshold comparison event on Channel 0. 
    ADC_ThresholdCompareFlagOnChn1 = 1U << 1U,  // Threshold comparison event on Channel 1. 
    ADC_ThresholdCompareFlagOnChn2 = 1U << 2U,  // Threshold comparison event on Channel 2. 
    ADC_ThresholdCompareFlagOnChn3 = 1U << 3U,  // Threshold comparison event on Channel 3. 
    ADC_ThresholdCompareFlagOnChn4 = 1U << 4U,  // Threshold comparison event on Channel 4. 
    ADC_ThresholdCompareFlagOnChn5 = 1U << 5U,  // Threshold comparison event on Channel 5. 
    ADC_ThresholdCompareFlagOnChn6 = 1U << 6U,  // Threshold comparison event on Channel 6. 
    ADC_ThresholdCompareFlagOnChn7 = 1U << 7U,  // Threshold comparison event on Channel 7. 
    ADC_ThresholdCompareFlagOnChn8 = 1U << 8U,  // Threshold comparison event on Channel 8. 
    ADC_ThresholdCompareFlagOnChn9 = 1U << 9U,  // Threshold comparison event on Channel 9. 
    ADC_ThresholdCompareFlagOnChn10= 1U << 10U, // Threshold comparison event on Channel 10. 
    ADC_ThresholdCompareFlagOnChn11= 1U << 11U, // Threshold comparison event on Channel 11. 
    ADC_OverrunFlagForChn0 =         1U << 12U, // Mirror the OVERRUN status flag from the result register for ADC channel 0. 
    ADC_OverrunFlagForChn1 =         1U << 13U, // Mirror the OVERRUN status flag from the result register for ADC channel 1. 
    ADC_OverrunFlagForChn2 =         1U << 14U, // Mirror the OVERRUN status flag from the result register for ADC channel 2. 
    ADC_OverrunFlagForChn3 =         1U << 15U, // Mirror the OVERRUN status flag from the result register for ADC channel 3. 
    ADC_OverrunFlagForChn4 =         1U << 16U, // Mirror the OVERRUN status flag from the result register for ADC channel 4. 
    ADC_OverrunFlagForChn5 =         1U << 17U, // Mirror the OVERRUN status flag from the result register for ADC channel 5. 
    ADC_OverrunFlagForChn6 =         1U << 18U, // Mirror the OVERRUN status flag from the result register for ADC channel 6. 
    ADC_OverrunFlagForChn7 =         1U << 19U, // Mirror the OVERRUN status flag from the result register for ADC channel 7. 
    ADC_OverrunFlagForChn8 =         1U << 20U, // Mirror the OVERRUN status flag from the result register for ADC channel 8. 
    ADC_OverrunFlagForChn9 =         1U << 21U, // Mirror the OVERRUN status flag from the result register for ADC channel 9. 
    ADC_OverrunFlagForChn10 =        1U << 22U, // Mirror the OVERRUN status flag from the result register for ADC channel 10. 
    ADC_OverrunFlagForChn11 =        1U << 23U, // Mirror the OVERRUN status flag from the result register for ADC channel 11. 
    ADC_GlobalOverrunFlagForSeqA =   1U << 24U, // Mirror the glabal OVERRUN status flag for conversion sequence A. 
    ADC_GlobalOverrunFlagForSeqB =   1U << 25U, // Mirror the global OVERRUN status flag for conversion sequence B. 
    ADC_ConvSeqAInterruptFlag =      1U << 28U, // Sequence A interrupt/DMA trigger. 
    ADC_ConvSeqBInterruptFlag =      1U << 29U, // Sequence B interrupt/DMA trigger. 
    ADC_ThresholdCompareInterruptFlag=1U << 30U,// Threshold comparision interrupt flag. 
    ADC_OverrunInterruptFlag =       1U << 31U, // Overrun interrupt flag. 
} ADCn_Ch_e;

typedef enum  //ADCģ��
{
    //ADCͨ�� �ܽŹ�ϵ        LQ_546XXP100SYS       
    ADC0CH0=0,     //P0_10    ����                  
    ADC0CH1=1,     //P0_11    ���ã�SWD�������ڣ�   
    ADC0CH2=2,     //P0_12    ���ã�SWD�������ڣ�   
    ADC0CH3=3,     //P0_15    ����                  
    ADC0CH4=4,     //P0_16    ����                  
    ADC0CH5=5,     //P0_31    ����                  
    ADC0CH6=6,     //P1_0     ����                  
    ADC0CH7=7,     //P2_0    �޴˹ܽţ� ������      
    ADC0CH8=8,     //P2_1    �޴˹ܽţ� ������      
    ADC0CH9=9,     //P3_21   �޴˹ܽţ� ������      
    ADC0CH10=10,   //P3_22   �޴˹ܽţ� ������      
    ADC0CH11=11,   //P0_23    ����                   
    /*
    ADC0CH12=12,
    ADC0CH13=13,
    ADC0CH14=14,
    ADC0CH15=15,
    ADC0CH16=16,
    ADC0CH17=17,
    ADC0CH18=18,
    ADC0CH19=19,
    ADC0CH20=20,        
    ADC0CH21=21,    
    ADC0CH22=22,
    ADC0CH23=23,
    ADC0CH24=24,
    ADC0CH25=25,
    ADC0CH26=26,
    ADC0CH27=27,
    ADC0CH28=28,
    ADC0CH29=29,
    ADC0CH30=30,
    ADC0CH31=31,    
    */
} ADCn_Ch;

//����λ��
typedef enum ADC_nbit
{
    ADC_8bit   = 0x01,
    ADC_10bit  = 0x02,
    ADC_12bit  = 0x03,
} ADC_nbit;


//----------------------------------------------------------------
//������: ADC_init                                                
//��  ��: ��ʼ��ADC                                               
//��  ��: channel: ADCͨ��                                        
//��  ��: bit    : ADC�ֱ���                                        
//��  ��: ��                                                      
//��  ��: ADC0_Init(ADC0CH0,ADC_12bit);                       
//----------------------------------------------------------------
void ADC0_Init(ADCn_Ch channel,ADC_nbit bit);



/**
  * @brief    ��ȡADC�Ĳ���ֵ
  *
  * @param    channel ��adcͨ��
  *
  * @return   ����ֵ
  *
  * @note     ��
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
uint16_t ADC0_GetResult(ADCn_Ch channel);



/**
  * @brief    ����ADCͨ��
  *
  * @param    ��
  *
  * @return   ��
  *
  * @note     ��
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void Test_ADC(void);
#endif /* __MK60_ADC16_H__ */
