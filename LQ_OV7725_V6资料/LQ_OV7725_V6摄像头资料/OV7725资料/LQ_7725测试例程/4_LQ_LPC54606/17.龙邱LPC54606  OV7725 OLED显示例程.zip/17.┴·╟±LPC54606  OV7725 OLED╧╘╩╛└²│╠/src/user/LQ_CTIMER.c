/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
��ƽ    ̨�������������ܿƼ�LPC546XX���İ�
����    д��CHIUSIR
����    ע��
�������汾��V1.0
�������¡�2017��11��27��
�������Ϣ�ο����е�ַ��
����    վ��http://www.lqist.cn
���Ա����̡�http://shop36265907.taobao.com
���������䡿chiusir@163.com
---------------------------------------------------------------- 
QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
#include "include.h"

/**
  * @brief    ��ʼ��CTIMERΪPWM�������
  *
  * @param    matchChannel   ��    CTIMERͨ��
  * @param    duty           ��    ռ�ձ� * CMTER_PWM_MAX
  * @param    pwmFreq_Hz     ��    Ƶ��
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
	  
void CTIMER_InitPwm(CTn_Pwm_Chn_e matchChannel,uint32_t duty,uint32_t pwmFreq_Hz)
{
	static uint8_t flag[5];
	CTIMER_Type     * TIMERN[] = CTIMER_BASE_PTRS;
	CTIMER_Type     * base = TIMERN[matchChannel/4];
	
	assert(pwmFreq_Hz > 0);
	uint32_t reg;   
	uint32_t index = CTIMER_GetInstance(base);
	ctimer_config_t cconfig;  
	if (matchChannel >= CT3_CH0)      
	{
		// Enable the asynchronous bridge 
		SYSCON->ASYNCAPBCTRL = 1;  
		// Ctimer3��4ʹ��12 MHz����ʱ��
		CLOCK_AttachClk(kFRO12M_to_ASYNC_APB);
		
		pwmFreq_Hz = (12000000u / pwmFreq_Hz) - 1; 
	}     
	else   
	{
		pwmFreq_Hz = (180000000u / pwmFreq_Hz) - 1;//BUSCLK=180Mʱ�� 
	}
	
	if ((matchChannel%4) == kCTIMER_Match_3)
	{
		return ;
	}
	/* ��ֹ�ظ���ʼ�� */
	if(flag[matchChannel/4] < 1)
	{
		flag[matchChannel/4]++;
		/* ��ʼ�� CTIMER */
		CTIMER_GetDefaultConfig(&cconfig);
		CTIMER_Init(base, &cconfig); 
	}
	
	
	/* ��ʼ����Ӧ�ܽ� */
	CTimer_PWMPinInit(matchChannel);
	
	/* Enable PWM mode on the channel */
	base->PWMC |= (1U << (matchChannel%4));
	
	/* Clear the stop, reset and interrupt bits for this channel */
	reg = base->MCR;
	reg &= ~((CTIMER_MCR_MR0R_MASK | CTIMER_MCR_MR0S_MASK | CTIMER_MCR_MR0I_MASK) << ((matchChannel%4) * 3));
	
	/* Reset the counter when match on channel 3 */
	reg |= CTIMER_MCR_MR3R_MASK;
	
	base->MCR = reg;  
	
	/* ����PWMƵ�� */
	base->MR[kCTIMER_Match_3] = pwmFreq_Hz;
	
	/* ����ռ�ձ� */
	base->MR[(matchChannel%4)] = (uint32_t)(pwmFreq_Hz * ((float)(CMTER_PWM_MAX - duty)/CMTER_PWM_MAX)); 
	
	/* �����־λ */
	CTIMER_ClearStatusFlags(base, CTIMER_IR_MR0INT_MASK << (matchChannel%4));
	
	CTIMER_StartTimer(base);
	return;
}


/**
  * @brief    CTIMER ����PWMռ�ձ�
  *
  * @param    base           ��    CTIMER��ַ
  * @param    matchChannel   ��    CTIMERͨ��
  * @param    duty           ��    ռ�ձ� * CMTER_PWM_MAX
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void CTIMER_SetDuty(CTn_Pwm_Chn_e matchChannel, uint32_t duty)
{ 
    CTIMER_Type     * TIMERN[] = CTIMER_BASE_PTRS;
    CTIMER_Type     * base = TIMERN[matchChannel/4];
    
    uint32_t pulsePeriod = 0, period;

    /* Match channel 3 defines the PWM period */
    period = base->MR[kCTIMER_Match_3];

    /* For 0% dutycyle, make pulse period greater than period so the event will never occur */
    if (duty == 0)
    {
        pulsePeriod = period + 1;
    }
    else
    {
        pulsePeriod = (uint32_t)(period * ((float)(CMTER_PWM_MAX - duty)/CMTER_PWM_MAX));
    }

    /* Update dutycycle */
    base->MR[(matchChannel%4)] = pulsePeriod;
}


/**
  * @brief    ����IO����ΪCTIMER PWM���
  *
  * @param    matchChannel   ��    CTIMERͨ��
  *
  * @return   
  *
  * @note     �ڲ�����
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void CTimer_PWMPinInit(CTn_Pwm_Chn_e CTn_CHn)
{        
    switch(CTn_CHn)
    {
      case  CT0_CH0:       
        if(CT0_OUT0==P0_0)
            IOCON_PinMuxSet(IOCON, 0, 0, PIOFun3_config);
        else if(CT0_OUT0==P0_30)
            IOCON_PinMuxSet(IOCON, 0,30, PIOFun4_config);
        else if(CT0_OUT0==P2_8)
            IOCON_PinMuxSet(IOCON, 2, 8, PIOFun4_config);           
        break;      
      case  CT0_CH1:        
        if(CT0_OUT1==P0_3)
            IOCON_PinMuxSet(IOCON, 0, 3, PIOFun3_config);
        else if(CT0_OUT1==P0_31)
            IOCON_PinMuxSet(IOCON, 0,31, PIOFun4_config);
        else if(CT0_OUT1==P2_9)
            IOCON_PinMuxSet(IOCON, 2, 9, PIOFun4_config);
        break;      
      case  CT0_CH2:        
        if(CT0_OUT2==P0_19)
            IOCON_PinMuxSet(IOCON, 0,19, PIOFun3_config);
        else if(CT0_OUT2==P1_31)
            IOCON_PinMuxSet(IOCON, 1,31, PIOFun4_config);
        else if(CT0_OUT2==P2_14)
            IOCON_PinMuxSet(IOCON, 2,14, PIOFun4_config);
        break;    
      case  CT1_CH0:       
        if(CT1_OUT0==P0_18)
            IOCON_PinMuxSet(IOCON, 0, 18, PIOFun3_config);
        else if(CT1_OUT0==P1_10)
            IOCON_PinMuxSet(IOCON, 1,10, PIOFun3_config);
        else if(CT1_OUT0==P2_1)
            IOCON_PinMuxSet(IOCON, 2, 1, PIOFun4_config);
        else if(CT1_OUT0==P3_0)
            IOCON_PinMuxSet(IOCON, 3, 0, PIOFun4_config);
        else if(CT1_OUT0==P4_23)
            IOCON_PinMuxSet(IOCON, 4, 23, PIOFun5_config);
        break;      
      case  CT1_CH1:        
        if(CT1_OUT1==P0_20)
            IOCON_PinMuxSet(IOCON, 0, 20, PIOFun2_config);
        else if(CT1_OUT1==P1_12)
            IOCON_PinMuxSet(IOCON, 1,12, PIOFun3_config);
        else if(CT1_OUT1==P2_2)
            IOCON_PinMuxSet(IOCON, 2, 2, PIOFun4_config);
        else if(CT1_OUT1==P3_1)
            IOCON_PinMuxSet(IOCON, 3, 1, PIOFun4_config); 
        else if(CT1_OUT1==P4_24)
            IOCON_PinMuxSet(IOCON, 4, 24, PIOFun5_config); 
        break;      
      case  CT1_CH2: 
        if(CT1_OUT2==P0_23)
            IOCON_PinMuxSet(IOCON, 0,23, PIOFun2_config);
        else if(CT1_OUT2==P1_14)
            IOCON_PinMuxSet(IOCON, 1,14, PIOFun3_config);
        else if(CT1_OUT2==P2_5)
            IOCON_PinMuxSet(IOCON, 2,5, PIOFun4_config);
        else if(CT1_OUT2==P3_2)
            IOCON_PinMuxSet(IOCON, 3, 2, PIOFun4_config); 
        else if(CT1_OUT2==P4_25)
            IOCON_PinMuxSet(IOCON, 4,25, PIOFun5_config);  
        break;       
      case  CT2_CH0: 
        if(CT2_OUT0==P0_10)
            IOCON_PinMuxSet(IOCON, 0,10, PIOFun3_config);
        else if(CT2_OUT0==P1_5)
            IOCON_PinMuxSet(IOCON, 1, 5, PIOFun3_config);
        else if(CT2_OUT0==P2_3)
            IOCON_PinMuxSet(IOCON, 2, 3, PIOFun4_config);     
        break;      
      case  CT2_CH1: 
        if(CT2_OUT1==P1_4)
            IOCON_PinMuxSet(IOCON, 1, 4, PIOFun3_config);
        else if(CT2_OUT1==P1_16)
            IOCON_PinMuxSet(IOCON, 1,16, PIOFun3_config);
        else if(CT2_OUT1==P2_4)
            IOCON_PinMuxSet(IOCON, 2, 4, PIOFun4_config);    
        break;      
      case  CT2_CH2: 
        if(CT2_OUT2==P0_11)
            IOCON_PinMuxSet(IOCON, 0,11, PIOFun2_config);
        else if(CT2_OUT2==P1_7)
            IOCON_PinMuxSet(IOCON, 1,7, PIOFun3_config);
        else if(CT2_OUT2==P2_30)
            IOCON_PinMuxSet(IOCON, 2,30, PIOFun4_config);
        break;      
      case  CT3_CH0: 
        if(CT3_OUT0==P0_5)
            IOCON_PinMuxSet(IOCON, 0, 5, PIOFun3_config);
        else if(CT3_OUT0==P4_30)
            IOCON_PinMuxSet(IOCON, 4,30, PIOFun3_config);
        else if(CT3_OUT0==P2_18)
            IOCON_PinMuxSet(IOCON, 2, 18, PIOFun4_config);
        else if(CT3_OUT0==P3_10)
            IOCON_PinMuxSet(IOCON, 3, 10, PIOFun3_config);  
        break;      
      case  CT3_CH1: 
        if(CT3_OUT1==P1_19)
            IOCON_PinMuxSet(IOCON, 1, 19, PIOFun3_config);
        else if(CT3_OUT1==P2_19)
            IOCON_PinMuxSet(IOCON, 2,19, PIOFun4_config);
        else if(CT3_OUT1==P3_14)
            IOCON_PinMuxSet(IOCON, 3, 14, PIOFun3_config);
        else if(CT3_OUT1==P4_31)
            IOCON_PinMuxSet(IOCON, 4, 31, PIOFun3_config);   
        break;      
      case  CT3_CH2: 
        if(CT3_OUT2==P0_27)
            IOCON_PinMuxSet(IOCON, 0,27, PIOFun3_config);
        else if(CT3_OUT2==P1_21)
            IOCON_PinMuxSet(IOCON, 1,21, PIOFun3_config);
        else if(CT3_OUT2==P2_20)
            IOCON_PinMuxSet(IOCON, 2,20, PIOFun4_config);
        else if(CT3_OUT2==P5_0)
            IOCON_PinMuxSet(IOCON, 5,0, PIOFun3_config);
        break;   
      case  CT4_CH0: 
        if(CT4_OUT0==P0_6)
            IOCON_PinMuxSet(IOCON, 0,  6, PIOFun3_config);
        else if(CT4_OUT0==P3_18)
            IOCON_PinMuxSet(IOCON, 3, 18, PIOFun3_config);
        else if(CT4_OUT0==P4_13)
            IOCON_PinMuxSet(IOCON, 4, 13, PIOFun2_config);
        break;      
      case  CT4_CH1: 
        if(CT4_OUT1==P3_5)
            IOCON_PinMuxSet(IOCON, 3,  5, PIOFun4_config);
        else if(CT4_OUT1==P3_19)
            IOCON_PinMuxSet(IOCON, 3, 19, PIOFun3_config);
        else if(CT4_OUT1==P4_14)
            IOCON_PinMuxSet(IOCON, 4, 14, PIOFun2_config);
        break;      
      case  CT4_CH2: 
        if(CT4_OUT2==P3_6)
            IOCON_PinMuxSet(IOCON, 3, 6, PIOFun4_config);
        else if(CT4_OUT2==P3_31)
            IOCON_PinMuxSet(IOCON, 3,31, PIOFun3_config);
        else if(CT4_OUT2==P4_15)
            IOCON_PinMuxSet(IOCON, 4,15, PIOFun2_config);
        break;   
      default:
        break;
    }           
}


/**
  * @brief    CTIMER ��ʼ��Ϊ�����������
  *
  * @param    
  *
  * @return   
  *
  * @note     ÿ��CTIMERģ��ֻ�ܼ�һ���������������ź�
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void CTIMER_PulseCounterInit( CTn_Cnt_Chn_e CTn_Cnt_CHn)
{         
    CTIMER_Type     * TIMERN[] = CTIMER_BASE_PTRS;
    CTIMER_Type     * base = TIMERN[CTn_Cnt_CHn/4];
    
    ctimer_config_t CTimerConfigStruct;
    
    // ����CTimerΪ���벶׽ģʽ��������ģʽ���½��ز�׽ 
    CTimerConfigStruct.mode = kCTIMER_IncreaseOnFallEdge;
    CTimerConfigStruct.input= (ctimer_capture_channel_t)(CTn_Cnt_CHn%4);  
    CTimerConfigStruct.prescale = 0U; // ���÷�Ƶ���� 
    
    switch(CTn_Cnt_CHn)
    {
      case  CT0_CNT_CH0:        
        if(CT0_CAP0==P0_1)
            IOCON_PinMuxSet(IOCON, 0, 1, PIOFun3_config);
        else if(CT0_CAP0==P0_13)
            IOCON_PinMuxSet(IOCON, 0,13, PIOFun3_config);
        else if(CT0_CAP0==P2_6)
            IOCON_PinMuxSet(IOCON, 2, 6, PIOFun4_config);           
        break;      
      case  CT0_CNT_CH1:       
        if(CT0_CAP1==P0_2)
            IOCON_PinMuxSet(IOCON, 0, 2, PIOFun2_config);
        else if(CT0_CAP1==P0_14)
            IOCON_PinMuxSet(IOCON, 0,14, PIOFun3_config);
        else if(CT0_CAP1==P2_7)
            IOCON_PinMuxSet(IOCON, 2, 7, PIOFun4_config);
        break;      
      case  CT0_CNT_CH2:       
        if(CT0_CAP2==P1_0)
            IOCON_PinMuxSet(IOCON, 1,0, PIOFun3_config);
        else if(CT0_CAP2==P1_28)
            IOCON_PinMuxSet(IOCON, 1,28, PIOFun3_config);
        else if(CT0_CAP2==P3_9)
            IOCON_PinMuxSet(IOCON, 3,9, PIOFun4_config);
        break;      
        
      case  CT0_CNT_CH3:       
        if(CT0_CAP3==P1_1)
            IOCON_PinMuxSet(IOCON, 1, 1, PIOFun3_config);
        else if(CT0_CAP3==P1_26)
            IOCON_PinMuxSet(IOCON, 1,26, PIOFun3_config);
        else if(CT0_CAP3==P4_3)
            IOCON_PinMuxSet(IOCON, 4, 3, PIOFun3_config);
        break;   
      case  CT1_CNT_CH0:        
        if(CT1_CAP0==P0_16)
            IOCON_PinMuxSet(IOCON, 0, 16, PIOFun3_config);
        else if(CT1_CAP0==P1_9)
            IOCON_PinMuxSet(IOCON, 1, 9, PIOFun3_config);
        else if(CT1_CAP0==P2_0)
            IOCON_PinMuxSet(IOCON, 2, 0, PIOFun4_config);
        else if(CT1_CAP0==P3_0)
            IOCON_PinMuxSet(IOCON, 3, 0, PIOFun4_config);
        else if(CT1_CAP0==P4_27)
            IOCON_PinMuxSet(IOCON, 4, 27, PIOFun5_config);
        break;      
      case  CT1_CNT_CH1:        
        if(CT1_CAP1==P1_11)
            IOCON_PinMuxSet(IOCON, 1, 11, PIOFun3_config);      
        else if(CT1_CAP1==P2_17)
            IOCON_PinMuxSet(IOCON, 2, 17, PIOFun4_config);
        else if(CT1_CAP1==P4_28)
            IOCON_PinMuxSet(IOCON, 4, 28, PIOFun5_config); 
        break;      
      case  CT1_CNT_CH2:      
        if(CT1_CAP2==P1_13)
            IOCON_PinMuxSet(IOCON, 1,13, PIOFun3_config);
        else if(CT1_CAP2==P4_17)
            IOCON_PinMuxSet(IOCON, 4,17, PIOFun3_config); 
        else if(CT1_CAP2==P4_29)
            IOCON_PinMuxSet(IOCON, 4,29, PIOFun5_config);  
        break; 
      case  CT1_CNT_CH3:       
        if(CT1_CAP3==P1_15)
            IOCON_PinMuxSet(IOCON, 1, 15, PIOFun3_config);     
        else if(CT1_CAP3==P4_18)
            IOCON_PinMuxSet(IOCON, 4, 18, PIOFun3_config);
        else if(CT1_CAP3==P4_30)
            IOCON_PinMuxSet(IOCON, 4, 30, PIOFun5_config);   
        break;  
      case  CT2_CNT_CH0:       
        if(CT2_CAP0==P0_24)
            IOCON_PinMuxSet(IOCON, 0, 24, PIOFun3_config);
        else if(CT2_CAP0==P2_22)
            IOCON_PinMuxSet(IOCON, 2, 22, PIOFun3_config);     
        break;      
      case  CT2_CNT_CH1:       
        if(CT2_CAP1==P0_25)
            IOCON_PinMuxSet(IOCON, 0, 25, PIOFun3_config);
        else if(CT2_CAP1==P2_26)
            IOCON_PinMuxSet(IOCON, 2, 26, PIOFun3_config);  
        break;      
      case  CT2_CNT_CH2:       
        if(CT2_CAP2==P0_10)
            IOCON_PinMuxSet(IOCON, 0, 10, PIOFun2_config);
        else if(CT2_CAP2==P2_28)
            IOCON_PinMuxSet(IOCON, 2, 28, PIOFun4_config);
        break;   
      case  CT2_CNT_CH3:      
        if(CT2_CAP3==P0_28)
            IOCON_PinMuxSet(IOCON, 0, 28, PIOFun3_config);
        else if(CT2_CAP3==P2_29)
            IOCON_PinMuxSet(IOCON, 2, 29, PIOFun4_config);          
        break;  
      case  CT3_CNT_CH0:       
        if(CT3_CAP0==P0_4)
            IOCON_PinMuxSet(IOCON, 0, 4, PIOFun3_config);
        else if(CT3_CAP0==P5_2)
            IOCON_PinMuxSet(IOCON, 5, 2, PIOFun3_config);
        else if(CT3_CAP0==P3_12)
            IOCON_PinMuxSet(IOCON, 3, 12, PIOFun3_config);  
        break;      
      case  CT3_CNT_CH1:      
        if(CT3_CAP1==P0_6)
            IOCON_PinMuxSet(IOCON, 0, 6, PIOFun2_config);
        else if(CT3_CAP1==P3_13)
            IOCON_PinMuxSet(IOCON, 3,13, PIOFun3_config);
        else if(CT3_CAP1==P5_3)
            IOCON_PinMuxSet(IOCON, 5, 3, PIOFun3_config);   
        break;      
      case  CT3_CNT_CH2:      
        if(CT3_CAP2==P0_26)
            IOCON_PinMuxSet(IOCON, 0,26, PIOFun3_config);
        else if(CT3_CAP2==P1_20)
            IOCON_PinMuxSet(IOCON, 1,20, PIOFun3_config);
        else if(CT3_CAP2==P5_4)
            IOCON_PinMuxSet(IOCON, 5,4, PIOFun3_config);
        break;
      case  CT3_CNT_CH3:       
        if(CT3_CAP3==P0_20)
            IOCON_PinMuxSet(IOCON, 0,20, PIOFun3_config);
        else if(CT3_CAP3==P0_22)
            IOCON_PinMuxSet(IOCON, 0,22, PIOFun3_config);
        else if(CT3_CAP3==P5_5)
            IOCON_PinMuxSet(IOCON, 5, 5, PIOFun3_config);
        break;     
      case  CT4_CNT_CH0:      
        if(CT4_CAP0==P0_15)
            IOCON_PinMuxSet(IOCON, 0, 15, PIOFun3_config);
        else if(CT4_CAP0==P3_24)
            IOCON_PinMuxSet(IOCON, 3, 24, PIOFun2_config);
        else if(CT4_CAP0==P2_20)
            IOCON_PinMuxSet(IOCON, 2, 20, PIOFun5_config);
        break;      
      case  CT4_CNT_CH1:       
        if(CT4_CAP1==P3_4)
            IOCON_PinMuxSet(IOCON, 3,  4, PIOFun4_config);
        else if(CT4_CAP1==P4_0)
            IOCON_PinMuxSet(IOCON, 4,  0, PIOFun3_config);
        break;      
      case  CT4_CNT_CH2:       
        if(CT4_CAP2==P3_7)
            IOCON_PinMuxSet(IOCON, 3, 7, PIOFun4_config);
        else if(CT4_CAP2==P3_25)
            IOCON_PinMuxSet(IOCON, 3,25, PIOFun2_config);
        else if(CT4_CAP2==P4_19)
            IOCON_PinMuxSet(IOCON, 4,19, PIOFun4_config);
        break;           
      case  CT4_CNT_CH3:      
        if(CT4_CAP3==P3_8)
            IOCON_PinMuxSet(IOCON, 3, 8, PIOFun4_config);
        else if(CT4_CAP3==P4_7)
            IOCON_PinMuxSet(IOCON, 4, 7, PIOFun2_config);
        else if(CT4_CAP3==P4_20)
            IOCON_PinMuxSet(IOCON, 4,20, PIOFun4_config);
        break;             
      default:
        break;
    }   
    
    CTIMER_Init(base, &CTimerConfigStruct);
    CTIMER_StartTimer(base);
     
}

/**
  * @brief    CTIMER �õ�����ֵ
  *
  * @param    CTn_Cnt_CHn �� ����ͨ��
  *
  * @return   �������ֵ
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
uint32_t CTIMER_GetCounter( CTn_Cnt_Chn_e CTn_Cnt_CHn)
{       
    CTIMER_Type     * TIMERN[] = CTIMER_BASE_PTRS;
    CTIMER_Type     * base = TIMERN[CTn_Cnt_CHn/4];
    
    return CTIMER_GetCurrentTimerCounter(base);
    
}


/**
  * @brief    CTIMER ���������
  *
  * @param    CTn_Cnt_CHn �� ����ͨ��
  *
  * @return   �������ֵ
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void CTIMER_ClearCounter( CTn_Cnt_Chn_e CTn_Cnt_CHn)
{    
    CTIMER_Type     * TIMERN[] = CTIMER_BASE_PTRS;
    CTIMER_Type     * base = TIMERN[CTn_Cnt_CHn/4];
    
    CTIMER_Reset(base);        
}











/*-----------------------------------------CTIMER����-------------------------------------------------*/


/**
  * @brief    �������
  *
  * @param    
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void Test_Servo(void)
{
    char txt[16];
     
    
    KEY_Init();          
    LED_Init();
    UART_Init(UART0,115200);
    CTIMER_InitPwm(CT4_CH0, 0, 50);//���Ƶ������

    printf("  ����������� \n");
    printf("��һ��ʹ�ö����ͬѧ������֮ǰ��ò�Ҫװ����ֹ���������ת�ջ� \n");
    printf("����ʹ��50Hz��PWM�źſ��� \n");
    printf("ʹ��1.5ms��Ϊ�������ֵ \n");
    printf("����K1����������� \n");
    printf("����K0����������� \n");
    printf("����K2����������� \n");
#ifdef OLED
    OLED_Init();
    OLED_CLS();                   //LCD����
    OLED_P8x16Str(4,0,(uint8_t*)"LQ Servo PWM");  
#else
    TFTSPI_Init(1);        //LCD��ʼ��  0:����  1������
    TFTSPI_CLS(u16BLUE);   //��ɫ��Ļ	  
    TFTSPI_P16x16Str(0,0,"�����������ܿƼ�",u16RED,u16BLUE);
#endif    
    
    uint16_t servopwm = 750;  
    while (1)
    {    
        switch(KEY_Read(1))  //
        {
            case 1:
                servopwm += 10;
                if(servopwm > 850)        //�����Լ���ʵ������Զ����ǽ������ƣ���ֹ����
                {
                    servopwm = 850;
                }
                CTIMER_SetDuty(CT4_CH0, servopwm);
                LED_Color_Reverse(red);
                break;           
            case 2:   
                servopwm = 750;
                CTIMER_SetDuty(CT4_CH0, servopwm);
                LED_Color_Reverse(blue);
                break;
            case 3:  
                servopwm -= 10;
                if(servopwm < 650)        //�����Լ���ʵ������Զ����ǽ������ƣ���ֹ����
                {
                    servopwm = 650;
                }
                CTIMER_SetDuty(CT4_CH0, servopwm);
                LED_Color_Reverse(green);
                break;
            default:
                LED_Color_Reverse(white);
                break;
        }
        
        sprintf(txt,"PWM: %05d %\n",servopwm);
#ifdef OLED
        OLED_P8x16Str(2,3,(uint8_t*)txt);
#else
        TFTSPI_P8X16Str(0,5,txt,u16RED,u16BLUE);
#endif
        
        printf(txt); //P0_30����� 
         
        systime.delay_ms(50);
    }
}



/*------------------------------------------------------------------------------------------------------
����    ����Test_Motor
����    �ܡ�FTM0���PWM�źſ��Ƶ������
����    ����num  :  ������  ��P0_18 �� P0_20 ���Ƶ��1  ��P1_4 �� P1_5���Ƶ��2
���� �� ֵ��duty �� ռ�ձ�    ��Χ -CMTER_PWM_MAX  �� +CMTER_PWM_MAX
��ʵ    ����MOTOR_Ctrl(Mot0, -1000);
��ע�����
--------------------------------------------------------------------------------------------------------*/
void MOTOR_Ctrl(Mot_CHn_e num, short duty)
{
    if(abs(duty) > CMTER_PWM_MAX)     //��ֹռ�ձȸ���
    {
        duty = 0;
    }
    switch(num)
    {
      case Mot0:
        if(duty > 0)
        {
            CTIMER_SetDuty(CT1_CH0, duty);
            CTIMER_SetDuty(CT1_CH1, 0);
        }
        else
        {
            CTIMER_SetDuty(CT1_CH0, 0);
            CTIMER_SetDuty(CT1_CH1, -duty);
        }
      case Mot1:
        if(duty > 0)
        {
            CTIMER_SetDuty(CT2_CH1, duty);
            CTIMER_SetDuty(CT2_CH0, 0);
        }
        else
        {
            CTIMER_SetDuty(CT2_CH1, 0);
            CTIMER_SetDuty(CT2_CH0, -duty);
        }
	  case Mot2:
        if(duty > 0)
        {
            /* �������� */
        }
        else
        {
            
        }
      case Mot3:
        if(duty > 0)
        {
            
        }
        else
        {
            
        }
        
    }

}

/**
  * @brief    �������
  *
  * @param    
  *
  * @return   
  *
  * @note     
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void Test_Motor(void)
{
    char txt[16];
     
    
    KEY_Init();          
    LED_Init();
    UART_Init(UART0,115200);
    CTIMER_InitPwm(CT1_CH0, 0, 12000);
	CTIMER_InitPwm(CT1_CH1, 0, 12000);
	CTIMER_InitPwm(CT2_CH0, 0, 12000);
	CTIMER_InitPwm(CT2_CH1, 0, 12000);

    printf("����������� \n");
    printf("��һ��ʹ�õ�ͬѧ������֮ǰ�����ʾ�����۲�һ�²��� \n");
    printf("����ʹ��12KHz��PWM�źſ��� \n");
    printf("����K1����������� \n");
    printf("����K0���������ǰ���� \n");
    printf("����K2������������� \n");
	
#ifdef OLED
    OLED_Init();
    OLED_CLS();                   //LCD����
    OLED_P8x16Str(4,0,(uint8_t*)"LQ Motor PWM");  
#else
    TFTSPI_Init(1);        //LCD��ʼ��  0:����  1������
    TFTSPI_CLS(u16BLUE);   //��ɫ��Ļ	  
    TFTSPI_P16x16Str(0,0,"�����������ܿƼ�",u16RED,u16BLUE);
#endif    
    
    short duty = 0;
    while (1)
    {    
        switch(KEY_Read(1))  //
        {
            case 1:
                duty += 10;
                if(duty > CMTER_PWM_MAX)        //�����Լ���ʵ������Զ����ǽ������ƣ���ֹ����
                {
                    duty = CMTER_PWM_MAX;
                }
                MOTOR_Ctrl(Mot0, duty);
				MOTOR_Ctrl(Mot1, duty);
                LED_Color_Reverse(red);
                break;           
            case 2:   
                duty = 0;
                MOTOR_Ctrl(Mot0, duty);
				MOTOR_Ctrl(Mot1, duty);
                LED_Color_Reverse(blue);
                break;
            case 3:  
                duty -= 10;
                if(duty < -CMTER_PWM_MAX)        //�����Լ���ʵ������Զ����ǽ������ƣ���ֹ����
                {
                    duty = -CMTER_PWM_MAX;
                }
                MOTOR_Ctrl(Mot0, duty);
				MOTOR_Ctrl(Mot1, duty);
                LED_Color_Reverse(green);
                break;
            default:
                LED_Color_Reverse(white);
                break;
        }
        
        sprintf(txt,"PWM: %06d",duty);
#ifdef OLED
        OLED_P8x16Str(2,3,(uint8_t*)txt);
#else
        TFTSPI_P8X16Str(0,5,txt,u16RED,u16BLUE);
#endif
        
		printf("PWM: %d \n", duty); 
         
        systime.delay_ms(50);
    }
}


/**
  * @brief    ���Դ����������
  *
  * @param    
  *
  * @return   
  *
  * @note     ʹ��Ctimer��������������壬ʹ����ͨIO�ջ�ȡ����������
  *
  * @example  
  *
  * @date     2019/5/7 ���ڶ�
  */
void Test_CtimerPulse(void)
{          
    LED_Init();
    UART_Init(UART0,115200);
    
#ifdef OLED
    OLED_Init();
    OLED_CLS();                   //LCD����
    OLED_P8x16Str(4,0,(uint8_t*)"LQ ENC PWM");  
#else
    TFTSPI_Init(1);        //LCD��ʼ��  0:����  1������
    TFTSPI_CLS(u16BLUE);   //��ɫ��Ļ	  
    TFTSPI_P16x16Str(0,0,"�����������ܿƼ�",u16RED,u16BLUE);
#endif 
    
    printf("���������������\n");
    printf("������1�ķ����P0_2   �����P0_1 \n");
    printf("������2�ķ����P1_15  �����P0_4 \n");
    
    CTIMER_PulseCounterInit(CT0_CNT_CH0);          //��CTIMER0 P0_1��Ϊ���������
    CTIMER_PulseCounterInit(CT3_CNT_CH0);          //��CTIMER3 P0_4��Ϊ���������
    
    IOCON_PinMuxSet(IOCON, 0, 2,  PIOFun0_config); // ����P0_2 ����ΪGPIO
    PT0_2_DIR=0;                                   //���������������
    
    IOCON_PinMuxSet(IOCON, 1, 15, PIOFun0_config); // ����P1_15����ΪGPIO
    PT1_15_DIR=0;                                  //���������������
    
    char txt[16];
    short speed1, speed2;
    uint64_t now_time = systime.get_time_us();
    while(1)
    {
        /* 10 000us ��ȡһ������ */
        if((systime.get_time_us() - now_time) >= 10000)
        {
            now_time = systime.get_time_us();
            if(PT0_2 == 0)
            {
                /* ��ȡ ����������ֵ */
                speed1 = -CTIMER_GetCounter(CT0_CNT_CH0);
            }
            else
            {
                /* ��ȡ ����������ֵ */
                speed1 = CTIMER_GetCounter(CT0_CNT_CH0);
            }
            /* ������� */
            CTIMER_ClearCounter(CT0_CNT_CH0);
            
            if(PT1_15 == 0)
            {
                /* ��ȡ ����������ֵ */
                speed2 = -CTIMER_GetCounter(CT3_CNT_CH0);
            }
            else
            {
                /* ��ȡ ����������ֵ */
                speed2 = CTIMER_GetCounter(CT3_CNT_CH0);
            }
            
            /* ������� */
            CTIMER_ClearCounter(CT3_CNT_CH0);
            
#ifdef OLED
            printf("\r\n/ENC1 %5d \r\n ",speed1);
            sprintf(txt,"enc1:%5d ",speed1);
            OLED_P8x16Str(20,2,(uint8_t*)txt);
            
            printf("\r\n/ENC2 %5d \r\n ",speed2);
            sprintf(txt,"enc2:%5d ",speed2);
            OLED_P8x16Str(20,4,(uint8_t*)txt);
#else
            printf("\r\n/ENC1 %5d \r\n ",speed1);
            sprintf(txt,"enc1:%5d ",speed1);
            TFTSPI_P8X16Str(2, 3, txt, u16RED, u16BLUE);
            
            printf("\r\n/ENC2 %5d \r\n ",speed2);
            sprintf(txt,"enc2:%5d ",speed2);
            TFTSPI_P8X16Str(2, 5, txt, u16RED, u16BLUE);
#endif            
            
            LED_Color_Reverse(green);
        }
        
    
    }
}


