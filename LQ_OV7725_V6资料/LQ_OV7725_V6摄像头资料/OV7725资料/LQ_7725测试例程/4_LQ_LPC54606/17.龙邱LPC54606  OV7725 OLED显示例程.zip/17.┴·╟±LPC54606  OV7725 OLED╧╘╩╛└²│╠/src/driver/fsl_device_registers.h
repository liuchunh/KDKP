
#ifndef __FSL_DEVICE_REGISTERS_H__
#define __FSL_DEVICE_REGISTERS_H__

#define LPC54606_SERIES

/* CMSIS-style register definitions */
#include "LPC54606.h"
/* CPU specific feature definitions */
#include "LPC54606_features.h"

#endif /* __FSL_DEVICE_REGISTERS_H__ */

/*******************************************************************************
 * EOF
 ******************************************************************************/
