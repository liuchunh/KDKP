/*LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
 【平    台】北京龙邱智能科技TC297TX核心板
 【编    写】ZYF/chiusir
 【E-mail  】chiusir@163.com
 【软件版本】V1.1 版权所有，单位使用请先联系授权
 【最后更新】2023年1月9日
 【相关信息参考下列地址】
 【网    站】http://www.lqist.cn
 【淘宝店铺】http://longqiu.taobao.com
 ------------------------------------------------
 【dev.env.】AURIX Development Studio1.3版本
 【Target 】 TC297TX
 【Crystal】 20.000Mhz
 【SYS PLL】 300MHz
 ________________________________________________________________

 QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ*/
/******************************************************************************/
#include "include.h"

unsigned char Image_Data[IMAGEH][IMAGEW];   //存放原始图像
uint8_t Image_Use[LCDH][LCDW];              //压缩后之后用于存放屏幕显示数据

/*************************************************************************
*  函数名称：OV7725_Init
*  功能说明：OV7725初始化函数
*  参数说明：fps：帧率（暂时最大值15）
*  函数返回：无
*  修改时间：2022年12月29日
*  备    注：G
*************************************************************************/
void OV7725_Init(uint8_t fps)
{
    uint8_t id[2];    //瀛樻斁鎽勫儚澶磇d
    uint16_t width = OV7725_IMAGEW, height = OV7725_IMAGEH;
    uint16_t hstart, vstart, hsize;
    char txt[16];

    /*SCCB通信初始化*/
    SCCB_Init();

    /*复位OV7725*/
    OV7725_SoftwareReset();

    /*延时最少2毫秒*/
    delayms(5);

    /*7725最大像素为 480*640 */
    if ((OV7725_IMAGEW > 640) || (OV7725_IMAGEH > 480))
    {
        TFTSPI_P8X16Str(0,2,"7725 dpi!!",u16RED,u16BLUE);
        while(1);
    }
    SCCB_RegRead_Int8(OV7725_SCCB_ADDR,OV7725_PID_REG,&id[0]);  //读取设备ID高八位
    SCCB_RegRead_Int8(OV7725_SCCB_ADDR,OV7725_VER_REG,&id[1]);  //读取设备ID低八位
    sprintf(txt, "ID:%02x %02x", id[0], id[1]);
    TFTSPI_P8X16Str(0,3,txt,u16RED,u16BLUE);
    if(OV7725_REVISION != (((uint32_t)id[0] << 8U) | (uint32_t)id[1]))//判断读取的ID是否正确
    {
        TFTSPI_P8X16Str(0,2,"7725 NG",u16RED,u16BLUE);
        while(1);
    }else{
        TFTSPI_P8X16Str(0,2,"7725 OK",u16RED,u16BLUE);
    }
    delayms(500);   //延时的主要作用是查看读取结果

    OV7725_Init_Regs(); //先按官方的初始化方式初始化摄像头 后续再改动

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM2_REG, 0x03);  //COM2控制    软睡眠模式 Bit[4]  输出驱动能力 Bit[1:0]: 00: 1x 01: 2x 10: 3x 11: 4x

#if 1    //RGB565 格式数据
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM7_REG, 0x46);  // 输出像素大小QVGA（240*320） 数据格式RGB565
                                                                 /* OV7725_COM7_REG
                                                                    Bit[7]: 将所有寄存器重置为默认值
                                                                    0: 不变
                                                                    1: 将所有寄存器重置为默认值
                                                                    Bit[6]: 选择分辨率
                                                                    0: VGA
                                                                    1: QVGA
                                                                    Bit[5]: BT.656选择开关
                                                                    Bit[4]: Sensor RAW
                                                                    Bit[3:2]: RGB输出格式
                                                                    00: GBR4:2:2
                                                                    01: RGB565
                                                                    10: RGB555
                                                                    11: RGB444
                                                                    Bit[1:0]: 输出格式控制
                                                                    00: YUV
                                                                    01: Processed Bayer RAW
                                                                    10: RGB
                                                                    11: Bayer RAW */
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM3_REG, 0x00); //Bit[6]: 水平镜像控制 0水平镜像关 1水平镜像开
                                                                //Bit[5]: 在RGB输出模式下交换B/R输出序列
                                                                //Bit[4]: 在YuV输出模式下交换Y/uV输出序列   (参见寄存器DSP Ctrl3[71 (Ox66))
                                                                //Bit[3]: 交换输出MSB/LSB
    hstart = (0x3fU << 2U);     //图像水平开始位置
    vstart = (0x03U  << 1U) ;   //图像垂直开始位置
#else   //
    /*OV7725_COM7_REG
    Bit[7]: 重置寄存器
    0: 不重置
    1: 将所有寄存器重置为默认值
    Bit[6]: 分辨率设置（7725输出支持两种分辨率，其他的任意自定义分辨率相当于截取这两种分辨率其中的一部分，会丢失视野）
    0: VGA
    1: QVGA
    Bit[5]: BT.656协议开/关选择
    Bit[4]: 传感器的原始值
    Bit[3:2]: RGB输出格式控件
    00: GBR4:2:2
    01: RGB565
    10: RGB555
    11: RGB444
    Bit[1:0]: 输出格式控制
    00: YUV
    01: Processed Bayer RAW
    10: RGB
    11: Bayer RAW */
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM7_REG, 0x43);  //  浣跨敤QVGA 鍜� Bayer RAW 鏍煎紡

    //Bit[6]: 0水平镜像关 1水平镜像开  注意开启水平镜像时最好开启0x32寄存器的Bit[7]:镜像图像边缘对齐-在镜像模式下应该设置为1
    //Bit[4]: 0 UYVY模式  1 YUYV模式
    //Bit[3]: 大小端
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM3_REG, 0x00);

    hstart = 0x3fU << 2U;   //鍥惧儚姘村钩寮�濮嬩綅缃�
    vstart = 0x03U << 1U;   //鍥惧儚鍨傜洿寮�濮嬩綅缃�
#endif
    /*Bit[1:0]: Output selection
      00: YUV or RGB
      01: YUV or RGB
      10: RAW8
      11: RAW10*/
//    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_DSP_CTRL4_REG, 0x4a);

    /*Bit[7]: 启用快速AGC/AEC算法
    Bit[6]: AEC -步长限制
    0: 步长限于垂直空白
    1: 无限的步长
    Bit[5]: 带过滤开/关
    Bit[4]: 启用低于条带值的AEC
    0: 将曝光时间限制在1/100或1/120
            其次在任何光照条件下当启用带通滤波器
    1: 允许曝光时间小于1/100或1/120
            其次在强光条件下当启用带通滤波器
    Bit[3]: 良好的AEC开/关控制
    0: 限制最小曝光时间为一行
    1: 允许曝光时间小于一行
    Bit[2]: 自动增益控制使
    0: 手动模式
    1: 自动模式
    Bit[1]: AWB Enable
    0: 手动模式
    1: 自动模式
    Bit[0]: AEC Enable
    0: 手动模式
    1: 自动模式*/
//    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM8_REG, 0xff);

    /*对比度设置 归一化值为0x20  越小对比度越大*/
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_CNST_REG, 0x20);
//    ack += SCCB_RegWrite(OV7725_SCCB_ADDR,OV7725_BRIGHT_REG, 0x20);/*亮度设置*/
//    ack += SCCB_RegWrite(OV7725_SCCB_ADDR,OV7725_SIGN_REG, 0x20);/*亮度设置*/

    OV7725_SetFPS(fps);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR, OV7725_EXHCL_REG, 0x00); //虚拟像素插入LSB用于在水平方向插入虚拟像素的LSB
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR, OV7725_ADVFL_REG, 0x00); //垂直同步插入虚拟行(1位等于1行)的LSB
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR, OV7725_ADVFH_REG, 0x00); //垂直同步插入虚拟行的MSB
    /* Resolution and timing. */
    hsize = width + 16;

    /* 设置输出图片大小. */

    //水平起始位置高位  因为寄存器是8位的 最大255，像素最大640 * 480 放不下，用了10位数据，这里是高8位，剩下的两位放在OV7725_HREF_REG中
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_HSTART_REG, hstart >> 2U);

    //水平宽度高位      因为寄存器是8位的 最大255，像素最大640 * 480 放不下，用了10位数据，这里是高8位，剩下的两位放在OV7725_HREF_REG中
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_HSIZE_REG, hsize >> 2U);

    //垂直起始位置高位  因为寄存器是8位的 最大255，像素最大640 * 480 放不下，用了9位数据，这里是高8位，剩下的两位放在OV7725_HREF_REG中
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VSTART_REG, vstart >> 1U);

    //垂直高度高位      因为寄存器是8位的 最大255，像素最大640 * 480 放不下，用了9位数据，这里是高8位，剩下的两位放在OV7725_HREF_REG中
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VSIZE_REG, height >> 1U);

    //水平输出宽度高位  因为寄存器是8位的 最大255，像素最大640 * 480 放不下，用了10位数据，这里是高8位，剩下的两位放在OV7725_EXHCH_REG中
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_HOUTSIZE_REG, width >> 2U);

    //垂直输出高度高位  因为寄存器是8位的 最大255，像素最大640 * 480 放不下，用了9位数据，这里是高8位，剩下的两位放在OV7725_EXHCH_REG中
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VOUTSIZE_REG, height >> 1U);

    //水平宽度和垂直高度的低位
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_HREF_REG,
                    ((vstart & 1U) << 6U) | ((hstart & 3U) << 4U) | ((height & 1U) << 2U) | ((hsize & 3U) << 0U));

    //水平输出和垂直输出的低2位和低1位
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_EXHCH_REG, ((height & 1U) << 2U) | ((width & 3U) << 0U));

    OV7725_LightModeConfigs(3);
}

/*------------------------------------------------------------------------------------------------------
【函    数】OV7725_SetFPS
【功    能】设置FPS
【参    数】fps
【返 回 值】无
【实    例】
【注意事项】配置的是摄像头的帧率输出，帧率越高，单片机的新能要求越高
--------------------------------------------------------------------------------------------------------*/
void OV7725_SetFPS(uint8_t fps)
{
    if(fps > 75)
    {
        /* 锁相环8倍频 满窗口
        Bit[7:6]: 锁相环倍频器控制
        00: 不用倍频
        01: 4倍频
        10: 6倍频
        11: 8倍频
        Bit[5:4]: 自动曝光窗口大小
        00: Full window
        01: 1/2 window
        10: 1/4 window
        11: Low 2/3 window*/
        SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM4_REG, 0xC1);  //PCLK 48M
    }
    else
    {
        SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM4_REG, 0x41);  //PCLK 24M
    }
    uint16_t dm_lnl = 0;                                               //虚拟行
    uint8_t  div    = 1;                                               //时钟分频系数
    if(fps > 150)
    {
        fps = 150;
        div = 1;
        dm_lnl = 0;
    }
    else if(fps > 75)
    {
        div = 1;
        dm_lnl = (uint16_t)((150 - fps) / 150.0 * (OV7725_IMAGEH + 36*(div + 1)));
    }
    else if(fps > 50)
    {
        div = 1;
        dm_lnl = (uint16_t)((75 - fps) / 75.0 * (OV7725_IMAGEH + 36*(div + 1)));
    }
    else if(fps > 37)
    {
        div = 2;
        dm_lnl = (uint16_t)((50 - fps) / 50.0 * (OV7725_IMAGEH + 36*(div + 1)));
    }
    else if(fps > 18)
    {
        div = 3;
        dm_lnl = (uint16_t)((37.5 - fps) / 37.5 * (OV7725_IMAGEH + 36*(div + 1)));
    }
    else
    {
        div = 14;
        dm_lnl = 0;
    }
    /*时钟配置 时钟 = PCLK * 4 / （（1+1）*4） 时钟越高，帧率越快 不过DMA可能接受不了会有噪点
    Bit[6]: 直接使用外部时钟(没有时钟预刻度可用)
    Bit[5:0]: 时钟 = PCLK × 锁相环倍频器 /[(CLKRC[5:0] + 1) × 4]*/
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR, OV7725_CLKRC_REG, div);

    /*虚拟行低八位， 增加虚拟行可以降低帧率，适当添加把帧率配置到自己想要的帧率*/
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR, OV7725_DM_LNL_REG, (uint8_t)dm_lnl);

    /*虚拟行高八位*/
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR, OV7725_DM_LNH_REG, (uint8_t)(dm_lnl>>8));
}
/*------------------------------------------------------------------------------------------------------
【函    数】OV7725_Init_Regs
【功    能】自动曝光 VGA
【参    数】无
【返 回 值】无
【实    例】
【注意事项】
--------------------------------------------------------------------------------------------------------*/
void OV7725_Init_Regs(void)
{
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x3d, 0x03);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x42, 0x7f);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x4d, 0x09);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x64, 0xff);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x65, 0x20);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x66, 0x00);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x67, 0x48);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x0f, 0xc5);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x13, 0xff);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x63, 0xe0);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x14, 0x11);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x22, 0x3f);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x23, 0x07);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x24, 0x40);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x25, 0x30);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x26, 0xa1);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x2b, 0x00);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x6b, 0xaa);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x0d, 0x41);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x90, 0x05);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x91, 0x01);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x92, 0x03);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x93, 0x00);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x94, 0x90);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x95, 0x8a);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x96, 0x06);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x97, 0x0b);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x98, 0x95);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x99, 0xa0);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x9a, 0x1e);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x9b, 0x08);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x9c, 0x20);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x9e, 0x81);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0xa6, 0x04);

    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x7e, 0x0c);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x7f, 0x16);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x80, 0x2a);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x81, 0x4e);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x82, 0x61);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x83, 0x6f);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x84, 0x7b);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x85, 0x86);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x86, 0x8e);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x87, 0x97);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x88, 0xa4);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x89, 0xaf);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x8a, 0xc5);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x8b, 0xd7);
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,0x8c, 0xe8);
}

/*------------------------------------------------------------------------------------------------------
【函    数】OV7725_SoftwareReset
【功    能】复位摄像头 恢复默认配置
【参    数】无
【返 回 值】无
【实    例】
【注意事项】
--------------------------------------------------------------------------------------------------------*/
void OV7725_SoftwareReset(void)
{
    SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM7_REG, 0x80);
}
/*------------------------------------------------------------------------------------------------------
【函    数】OV7725_LightModeConfigs
【功    能】灯光配置
【参    数】0:自动模式1:晴天2,多云3,办公室4,家里5,夜晚
【返 回 值】无
【实    例】
【注意事项】
--------------------------------------------------------------------------------------------------------*/
void OV7725_LightModeConfigs(uint8_t mode)
{
    switch(mode)
    {
        case 1:  //晴天
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM8_REG, 0xfd);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_BLUE_REG, 0x5a);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_RED_REG, 0x5c);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM5_REG, 0x65);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFL_REG, 0x00);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFH_REG, 0x00);
            break;
        case 2:  //多云
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM8_REG, 0xfd);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_BLUE_REG, 0x58);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_RED_REG, 0x60);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM5_REG, 0x65);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFL_REG, 0x00);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFH_REG, 0x00);
            break;
        case 3:  //办公室
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM8_REG, 0xfd);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_BLUE_REG, 0x84);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_RED_REG, 0x4c);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM5_REG, 0x65);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFL_REG, 0x00);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFH_REG, 0x00);
            break;
        case 4:   //家里
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM8_REG, 0xfd);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_BLUE_REG, 0x96);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_RED_REG, 0x40);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM5_REG, 0x65);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFL_REG, 0x00);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFH_REG, 0x00);
            break;
        case 5:   //晚上
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM8_REG, 0xff);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_BLUE_REG, 0x80);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_RED_REG, 0x80);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM5_REG, 0xe5);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFL_REG, 0x00);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFH_REG, 0x00);
            break;
        default:   //自动模式
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM8_REG, 0xff);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_BLUE_REG, 0x80);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_RED_REG, 0x80);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_COM5_REG, 0x65);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFL_REG, 0x00);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_ADVFH_REG, 0x00);
            break;
    }
}
/*------------------------------------------------------------------------------------------------------
【函    数】OV7725_SpecialEffectConfigs
【功    能】特效配置
【参    数】0:普通模式 1.黑白 2.复古  3,偏蓝4,偏红5,偏绿 6,负片
【返 回 值】无
【实    例】
【注意事项】
--------------------------------------------------------------------------------------------------------*/
void OV7725_SpecialEffectConfigs(uint8_t mode)
{
    switch(mode)
    {
        case 1:  //黑白
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_SDE_REG, 0x26);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_UFIX_REG, 0x80);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VFIX_REG, 0x80);
            break;
        case 2:  //复古
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_SDE_REG, 0x1e);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_UFIX_REG, 0x40);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VFIX_REG, 0xa0);
            break;
        case 3:  //偏蓝
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_SDE_REG, 0x1e);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_UFIX_REG, 0xa0);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VFIX_REG, 0x40);
            break;
        case 4:   //偏红
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_SDE_REG, 0x1e);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_UFIX_REG, 0x80);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VFIX_REG, 0x40);
            break;
        case 5:   //偏绿
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_SDE_REG, 0x1e);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_UFIX_REG, 0x60);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VFIX_REG, 0x60);
            break;
        case 6:   //负片
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_SDE_REG, 0x46);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_UFIX_REG, 0x00);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VFIX_REG, 0x00);
            break;
        default:   //普通模式
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_SDE_REG, 0x06);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_UFIX_REG, 0x80);
            SCCB_RegWrite_Int8(OV7725_SCCB_ADDR,OV7725_VFIX_REG, 0x80);
            break;
    }
}

/***************************************************************
* @brief    TFT18屏 unsigned char 灰度数据显示
*
* @param    high_start ： 显示图像开始位置
* @param    wide_start ： 显示图像开始位置
* @param    high ： 显示图像高度
* @param    wide ： 显示图像宽度
* @param    ppic： 显示图像数据地址
* @return   无
* @note     注意 屏幕左上为 （0，0）
* @date     2019/12/3 星期二
***************************************************************/
void OV7725_TFTSPI_Road(unsigned char wide_start, unsigned char high_start, unsigned char high, unsigned char wide, uint8_t ppic[LCDH][LCDW])
{
    unsigned long i, j;
    /* 设置显示范围 */
    TFTSPI_Set_Pos(wide_start, high_start, wide_start + wide - 1, high_start + high - 1);
    unsigned short color;

    /* 显示图像 */
    for(i = 0; i < LCDH; i++)
    {
        for(j = 0; j < LCDW; j += 2)
        {
            //合成16位的RGB565像素数据
            color = ppic[i][j];
            color = color<<8 | ppic[i][j+1];
            /* 显示 */
            TFTSPI_Write_Word (color);
        }
    }
}

void Ov7725_Init (unsigned char fps)
{
    //禁止中断
    IfxCpu_disableInterrupts();

    /* 初始化数据位 */
    PIN_InitConfig(P02_0, PIN_MODE_INPUT_PULLDOWN, 0);
    PIN_InitConfig(P02_1, PIN_MODE_INPUT_PULLDOWN, 0);
    PIN_InitConfig(P02_2, PIN_MODE_INPUT_PULLDOWN, 0);
    PIN_InitConfig(P02_3, PIN_MODE_INPUT_PULLDOWN, 0);
    PIN_InitConfig(P02_4, PIN_MODE_INPUT_PULLDOWN, 0);
    PIN_InitConfig(P02_5, PIN_MODE_INPUT_PULLDOWN, 0);
    PIN_InitConfig(P02_6, PIN_MODE_INPUT_PULLDOWN, 0);
    PIN_InitConfig(P02_7, PIN_MODE_INPUT_PULLDOWN, 0);

    OV7725_Init(fps);

    /* DMA  */
    PIN_Exti(P00_4, PIN_IRQ_MODE_FALLING);

    /* DMA */
    DMA_CameraInitConfig((unsigned long) (&MODULE_P02.IN.U), (unsigned long) Image_Data, PIN_INT2_PRIORITY);

    /* 场中断*/
    PIN_Exti(P15_1, PIN_IRQ_MODE_RISING_FALLING);//双边沿触发
    /* 行中断*/
    PIN_Exti(P15_8, PIN_IRQ_MODE_RISING);

    /* 开启中断*/
    IfxCpu_enableInterrupts();
}

void Get_Use_Image(void)
{
    int i = 0,j = 0;
    int div_h = IMAGEH/LCDH;            //2
    int div_w = IMAGEW*2/LCDW;          //4
    for(i = 0; i  < IMAGEH; i+=div_h)   //240/2=120 隔一行取一行数据
    {
        for(j = 0;j < IMAGEW; j+=div_w) //640/4=160 隔一列取一列数据（每四个像素数据取两个 La Ma Lb Mb ）
        {
            Image_Use[i/2][j/2+1] = Image_Data[i][j];
            Image_Use[i/2][j/2] = Image_Data[i][j+1];
        }
    }
}
void Test_Ov7725 (void)
{

    TFTSPI_Init(0);               //TFT1.8横屏
    TFTSPI_CLS(u16BLUE);          //清屏 蓝色

    /* 摄像头初始化 */
    Ov7725_Init(18);

    printf("OV7725 Demo Start\n");  //必须要有,不然图像传输有误(暂时不明白其中原因,猜测跟中断优先级有关)
    while (1)
    {
        /*一帧图像标志位*/
        if(Field_Over_Flag)
        {
            /*裁剪图像*/
            Get_Use_Image();

            /*显示 120*160*/
            OV7725_TFTSPI_Road(0, 0, 120, 160, Image_Use);

            /*清除标志位*/
            Field_Over_Flag = 0;
            LED_Ctrl(LED0, RVS);
        }
    }
}

