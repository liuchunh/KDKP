del debug\obj\*.*     /q
del release\obj\*.*     /q
del debug\list\*.*     /q